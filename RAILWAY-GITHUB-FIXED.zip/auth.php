<?php
require_once 'config.php';
session_start();

$action = $_GET['action'] ?? '';

if ($action == 'register' && $_SERVER['REQUEST_METHOD'] == 'POST') {
    $user = $_POST['username'] ?? '';
    $pass = $_POST['password'] ?? '';
    
    if (strlen($user) < 3 || strlen($pass) < 6) {
        echo json_encode(['status' => 'error', 'message' => 'Usuário (min 3) e senha (min 6) obrigatórios.']);
        exit;
    }

    try {
        $pass_hash = password_hash($pass, PASSWORD_DEFAULT);
        $stmt = $db->prepare("INSERT INTO users (username, password) VALUES (?, ?)");
        $stmt->execute([$user, $pass_hash]);
        
        // Notificar Admin no Telegram
        $msg = "🔔 *Novo Registro*\n👤 Usuário: `$user`\n📅 Status: Aguardando Aprovação";
        $keyboard = [
            'inline_keyboard' => [
                [['text' => '✅ Aprovar', 'callback_data' => "approve_$user"]]
            ]
        ];
        sendTelegram('sendMessage', [
            'chat_id' => ADMIN_ID,
            'text' => $msg,
            'parse_mode' => 'Markdown',
            'reply_markup' => json_encode($keyboard)
        ]);
        
        echo json_encode(['status' => 'success', 'message' => 'Conta criada! Aguarde aprovação do admin.']);
    } catch (Exception $e) {
        echo json_encode(['status' => 'error', 'message' => 'Usuário já existe.']);
    }
    exit;
}

if ($action == 'login' && $_SERVER['REQUEST_METHOD'] == 'POST') {
    $user = $_POST['username'] ?? '';
    $pass = $_POST['password'] ?? '';
    
    $stmt = $db->prepare("SELECT * FROM users WHERE username = ?");
    $stmt->execute([$user]);
    $userData = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if ($userData && password_verify($pass, $userData['password'])) {
        if ($userData['status'] == 'pending') {
            echo json_encode(['status' => 'error', 'message' => 'Sua conta está pendente de aprovação.']);
        } elseif ($userData['status'] == 'approved') {
            $now = new DateTime();
            $expires = new DateTime($userData['expires_at']);
            if ($now > $expires) {
                echo json_encode(['status' => 'error', 'message' => 'Seu acesso expirou!']);
            } else {
                $_SESSION['user_id'] = $userData['id'];
                $_SESSION['username'] = $userData['username'];
                $_SESSION['expires_at'] = $userData['expires_at'];
                $_SESSION['max_devices'] = $userData['max_devices'];
                $_SESSION['allowed_gates'] = $userData['allowed_gates'];
                session_write_close(); // Libera sessão imediatamente após gravar
                echo json_encode(['status' => 'success']);
            }
        } else {
            echo json_encode(['status' => 'error', 'message' => 'Sua conta foi bloqueada.']);
        }
    } else {
        echo json_encode(['status' => 'error', 'message' => 'Usuário ou senha incorretos.']);
    }
    exit;
}

if ($action == 'logout') {
    session_destroy();
    header('Location: login.php');
    exit;
}

if ($action == 'change_password' && $_SERVER['REQUEST_METHOD'] == 'POST') {
    if (!isset($_SESSION['user_id'])) {
        echo json_encode(['status' => 'error', 'message' => 'Acesso negado.']);
        exit;
    }

    $user_id = $_SESSION['user_id'];
    $current = $_POST['current_password'] ?? '';
    $new = $_POST['new_password'] ?? '';

    if (strlen($new) < 6) {
        echo json_encode(['status' => 'error', 'message' => 'A nova senha deve ter no mínimo 6 caracteres.']);
        exit;
    }

    $stmt = $db->prepare("SELECT password FROM users WHERE id = ?");
    $stmt->execute([$user_id]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($user && password_verify($current, $user['password'])) {
        $new_hash = password_hash($new, PASSWORD_DEFAULT);
        $stmt = $db->prepare("UPDATE users SET password = ? WHERE id = ?");
        $stmt->execute([$new_hash, $user_id]);
        echo json_encode(['status' => 'success', 'message' => 'Senha atualizada com sucesso!']);
    } else {
        echo json_encode(['status' => 'error', 'message' => 'Senha atual incorreta.']);
    }
    exit;
}
?>
