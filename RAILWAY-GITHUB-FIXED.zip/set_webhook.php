<?php
require_once 'config.php';

// Detectar URL automática ou permitir manual
$current_url = "https://" . $_SERVER['HTTP_HOST'] . dirname($_SERVER['PHP_SELF']) . "/bot.php";

if (isset($_GET['url'])) {
    $url = $_GET['url'];
} else {
    $url = $current_url;
}

echo "<h2>Configurador de Webhook Drakenveil</h2>";
echo "Tentando configurar para: <b>$url</b><br><br>";

$api_url = "https://api.telegram.org/bot" . TELEGRAM_TOKEN . "/setWebhook?url=" . urlencode($url);

$res = file_get_contents($api_url);
$data = json_decode($res, true);

if ($data['ok']) {
    echo "<span style='color:green'>✅ Webhook configurado com sucesso!</span><br>";
    echo "Mensagem: " . $data['description'];
} else {
    echo "<span style='color:red'>❌ Erro ao configurar:</span><br>";
    echo "Código: " . $data['error_code'] . "<br>";
    echo "Descrição: " . $data['description'];
}

echo "<br><br><small>Se a URL acima estiver errada (ex: localhost), use: ?url=https://seusite.com/bot.php</small>";
?>
