<!DOCTYPE html>
<html lang="pt-br">
<head>
    <title>DRAKENVEIL | SECURE ACCESS</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600&family=Fira+Code:wght@400;700&display=swap">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/css/toastr.min.css">
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        
        body {
            background: #050000;
            color: #ff0000;
            font-family: 'Poppins', sans-serif;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            overflow: hidden;
            position: relative;
        }

        #matrix-canvas {
            position: fixed;
            top: 0;
            left: 0;
            z-index: 0;
            opacity: 0.15;
        }

        .container {
            position: relative;
            z-index: 1;
            perspective: 1000px;
        }

        .login-box {
            background: rgba(15, 0, 0, 0.85);
            backdrop-filter: blur(15px);
            border: 1px solid rgba(255, 0, 0, 0.3);
            padding: 40px;
            width: 400px;
            text-align: center;
            box-shadow: 0 25px 50px rgba(0, 0, 0, 0.5), 0 0 30px rgba(255, 0, 0, 0.1);
            border-radius: 24px;
            transition: all 0.5s cubic-bezier(0.4, 0, 0.2, 1);
            transform: translateY(0);
        }

        .login-box:hover {
            transform: translateY(-10px);
            box-shadow: 0 35px 70px rgba(0, 0, 0, 0.6), 0 0 40px rgba(255, 0, 0, 0.2);
            border-color: rgba(255, 0, 0, 0.6);
        }

        .header {
            margin-bottom: 35px;
        }

        .logo-icon {
            font-size: 3em;
            margin-bottom: 15px;
            filter: drop-shadow(0 0 10px #ff0000);
            animation: pulse 2s infinite;
        }

        @keyframes pulse {
            0%, 100% { transform: scale(1); opacity: 1; }
            50% { transform: scale(1.1); opacity: 0.8; }
        }

        .header h1 {
            font-size: 1.8em;
            letter-spacing: 4px;
            color: #fff;
            text-shadow: 0 0 10px rgba(255, 0, 0, 0.5);
            font-weight: 600;
        }

        .header p {
            font-size: 0.75em;
            color: #ff0000;
            text-transform: uppercase;
            letter-spacing: 2px;
            opacity: 0.7;
        }

        .form-group {
            margin-bottom: 20px;
            text-align: left;
        }

        input {
            background: rgba(255, 0, 0, 0.05);
            border: 1px solid rgba(255, 0, 0, 0.2);
            color: #fff;
            padding: 16px 20px;
            width: 100%;
            box-sizing: border-box;
            outline: none;
            font-family: 'Poppins', sans-serif;
            font-size: 0.9em;
            border-radius: 12px;
            transition: all 0.3s ease;
        }

        input:focus {
            background: rgba(255, 0, 0, 0.1);
            border-color: #ff0000;
            box-shadow: 0 0 15px rgba(255, 0, 0, 0.3);
        }

        input::placeholder {
            color: rgba(255, 255, 255, 0.3);
        }

        .btn-submit {
            background: linear-gradient(135deg, #ff0000 0%, #8b0000 100%);
            border: none;
            color: #fff;
            padding: 16px;
            width: 100%;
            cursor: pointer;
            font-weight: 600;
            letter-spacing: 1px;
            font-size: 1em;
            border-radius: 12px;
            transition: all 0.3s;
            box-shadow: 0 10px 20px rgba(255, 0, 0, 0.2);
            margin-top: 10px;
        }

        .btn-submit:hover {
            transform: translateY(-2px);
            box-shadow: 0 15px 30px rgba(255, 0, 0, 0.4);
            filter: brightness(1.2);
        }

        .btn-submit:active {
            transform: translateY(0);
        }

        .toggle-link {
            margin-top: 25px;
            font-size: 0.85em;
            cursor: pointer;
            color: rgba(255, 255, 255, 0.5);
            transition: all 0.3s;
            display: block;
        }

        .toggle-link strong {
            color: #ff0000;
            margin-left: 5px;
        }

        .toggle-link:hover {
            color: #fff;
        }

        .footer-info {
            margin-top: 30px;
            font-size: 0.65em;
            color: rgba(255, 0, 0, 0.4);
            letter-spacing: 1px;
            text-transform: uppercase;
        }
    </style>
</head>
<body>
    <canvas id="matrix-canvas"></canvas>
    
    <div class="container">
        <div class="login-box">
            <div class="header">
                <div class="logo-icon">🔒</div>
                <h1 id="title">DRAKENVEIL</h1>
                <p id="subtitle">SYSTEM_INITIALIZATION</p>
            </div>

            <form id="auth-form">
                <div class="form-group">
                    <input type="text" id="username" name="username" placeholder="Usuário" required>
                </div>

                <div class="form-group">
                    <input type="password" id="password" name="password" placeholder="Senha de Acesso" required>
                </div>

                <button type="submit" class="btn-submit" id="btn-text">CONECTAR</button>
            </form>

            <div class="toggle-link" onclick="toggleMode()">
                <span id="toggle-desc">Não possui acesso?</span><strong id="toggle-action">Solicitar Registro</strong>
            </div>

            <div class="footer-info">
                v2.5.0-HACKER // SECURE_SHELL_ACTIVE
            </div>
        </div>
    </div>

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/js/toastr.min.js"></script>

    <script>
        let isLogin = true;

        function toggleMode() {
            isLogin = !isLogin;
            $('#title').text(isLogin ? 'DRAKENVEIL' : 'REGISTRO');
            $('#subtitle').text(isLogin ? 'SYSTEM_INITIALIZATION' : 'NEW_ACCESS_REQUEST');
            $('#btn-text').text(isLogin ? 'CONECTAR' : 'REGISTRAR');
            $('#toggle-desc').text(isLogin ? 'Não possui acesso?' : 'Já possui conta?');
            $('#toggle-action').text(isLogin ? 'Solicitar Registro' : 'Fazer Login');
        }

        $('#auth-form').submit(function(e) {
            e.preventDefault();
            const action = isLogin ? 'login' : 'register';
            $.post('auth.php?action=' + action, $(this).serialize(), function(res) {
                const data = JSON.parse(res);
                if (data.status === 'success') {
                    if (isLogin) {
                        toastr.success('ACESSO CONCEDIDO');
                        setTimeout(() => { window.location.href = 'index.php'; }, 1000);
                    } else {
                        toastr.success(data.message);
                    }
                } else {
                    toastr.error(data.message);
                }
            });
        });

        // Matrix Effect Red
        const canvas = document.getElementById('matrix-canvas');
        const ctx = canvas.getContext('2d');
        canvas.width = window.innerWidth;
        canvas.height = window.innerHeight;
        const letters = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
        const fontSize = 14;
        const columns = canvas.width / fontSize;
        const drops = [];
        for (let i = 0; i < columns; i++) drops[i] = 1;
        function draw() {
            ctx.fillStyle = 'rgba(0, 0, 0, 0.05)';
            ctx.fillRect(0, 0, canvas.width, canvas.height);
            ctx.fillStyle = '#ff0000';
            ctx.font = fontSize + 'px monospace';
            for (let i = 0; i < drops.length; i++) {
                const text = letters.charAt(Math.floor(Math.random() * letters.length));
                ctx.fillText(text, i * fontSize, drops[i] * fontSize);
                if (drops[i] * fontSize > canvas.height && Math.random() > 0.975) drops[i] = 0;
                drops[i]++;
            }
        }
        setInterval(draw, 50);
    </script>
</body>
</html>
