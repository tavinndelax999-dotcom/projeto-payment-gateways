<?php
// Configurações do Banco de Dados SQLite
$db_file = __DIR__ . '/database.sqlite';
$db = new PDO("sqlite:$db_file");
$db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
$db->exec("PRAGMA journal_mode=WAL;"); // Melhora performance multi-acesso
$db->exec("PRAGMA synchronous=NORMAL;");

// Configuração de Fuso Horário (Brasília)
date_default_timezone_set('America/Sao_Paulo');

// Silêncio Total no Square Cloud
error_reporting(0);
ini_set('display_errors', 0);
ini_set('log_errors', 0);
ini_set('display_startup_errors', 0);
@ini_set('html_errors', 0);
@ini_set('implicit_flush', 0);
@ob_start(); // Previne qualquer saída acidental que gere log

// Criar tabelas se não existirem
$db->exec("CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT UNIQUE,
    password TEXT,
    status TEXT DEFAULT 'pending', -- pending, approved, blocked
    expires_at DATETIME DEFAULT NULL,
    max_devices INTEGER DEFAULT 1,
    allowed_gates TEXT DEFAULT 'all', -- comma separated or 'all'
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
)");

$db->exec("CREATE TABLE IF NOT EXISTS user_sessions (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER,
    device_name TEXT,
    device_ip TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY(user_id) REFERENCES users(id)
)");

$db->exec("CREATE TABLE IF NOT EXISTS approval_requests (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT UNIQUE,
    status TEXT DEFAULT 'pending',
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
)");

// Configurações do Telegram
define('TELEGRAM_TOKEN', '8472590321:AAEOleAwyIJfPYnRIp9CIx0X4Ijvk7XLhGU');
define('ADMIN_ID', '7583584513');

function sendTelegram($method, $data) {
    $url = "https://api.telegram.org/bot" . TELEGRAM_TOKEN . "/" . $method;
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($data));
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_TIMEOUT, 10);
    $res = curl_exec($ch);
    curl_close($ch);
    return json_decode($res, true);
}

// Gateways disponíveis
$AVAILABLE_GATES = [
    'paypal3.php' => 'PayPal V3 (Ultra)',
    'paypal1.php' => 'PayPal V1 (New)',
    'paypal.php' => 'PayPal V2 (Old)',
    'erede1.php' => 'Pagar-me',
    'stripe0auth.php' => 'Stripe 0Auth',
    'stripeee.php' => 'Stripe Debit (1.00$)',
    'braindokgarr.php' => 'Braintree B3'
];

// Configuração de Proxy (Deixe em branco se não for usar)
// Formato: ip:porta ou ip:porta:user:pass
$PROXY_LIST = ""; 

function getProxy() {
    global $PROXY_LIST;
    if (empty($PROXY_LIST)) return null;
    $proxies = explode("\n", str_replace("\r", "", trim($PROXY_LIST)));
    if (empty($proxies)) return null;
    $p = trim($proxies[array_rand($proxies)]);
    $parts = explode(":", $p);
    if (count($parts) >= 4) {
        return ['proxy' => $parts[0].':'.$parts[1], 'auth' => $parts[2].':'.$parts[3]];
    }
    return ['proxy' => $p, 'auth' => null];
}
?>
