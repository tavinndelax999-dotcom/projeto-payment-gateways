<?php
require_once 'config.php';
session_start();

if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}

$user_id = $_SESSION['user_id'];
$username = $_SESSION['username'];
$expires_at = $_SESSION['expires_at'];

// Buscar dados do usuário
$stmt = $db->prepare("SELECT * FROM users WHERE id = ?");
$stmt->execute([$user_id]);
$user = $stmt->fetch(PDO::FETCH_ASSOC);

// Calcular tempo restante
$now_ts = time();
$expires_ts = strtotime($expires_at);
$time_left_seconds = $expires_ts - $now_ts;

if ($time_left_seconds <= 0) {
    session_destroy();
    header('Location: login.php');
    exit;
}
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <title>DRAKENVEIL | PERFIL</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600&family=Fira+Code:wght@400;700&display=swap">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <style>
        body { background: #050000; color: #fff; font-family: 'Poppins', sans-serif; min-height: 100vh; }
        .glass-card {
            background: rgba(15, 0, 0, 0.8);
            backdrop-filter: blur(15px);
            border: 1px solid rgba(255, 0, 0, 0.2);
            border-radius: 24px;
            padding: 25px;
            margin-top: 50px;
        }
        .form-control-hacker {
            background: rgba(255, 255, 255, 0.05);
            border: 1px solid rgba(255, 255, 255, 0.1);
            border-radius: 12px;
            color: #fff;
            padding: 12px 15px;
            width: 100%;
            margin-bottom: 15px;
        }
        .btn-start { background: linear-gradient(135deg, #ff0000 0%, #8b0000 100%); color: #fff; border: none; padding: 12px; border-radius: 12px; width: 100%; font-weight: 600; }
    </style>
</head>
<body>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-6">
                <div class="glass-card">
                    <h2 class="text-center mb-4" style="color: #ff0000; letter-spacing: 2px;">PERFIL DO USUÁRIO</h2>
                    <div class="mb-4 p-3" style="background: rgba(255,0,0,0.05); border-radius: 12px; border: 1px solid rgba(255,0,0,0.1);">
                        <p><strong>Usuário:</strong> <?php echo htmlspecialchars($username); ?></p>
                        <p><strong>Expira em:</strong> <?php echo date('d/m/Y H:i:s', $expires_ts); ?></p>
                        <p><strong>Tempo Restante:</strong> <span id="timer"></span></p>
                    </div>

                    <h4 class="mb-3" style="color: #ff0000;">Alterar Senha</h4>
                    <form id="changePasswordForm">
                        <input type="password" id="current_password" class="form-control-hacker" placeholder="Senha Atual" required>
                        <input type="password" id="new_password" class="form-control-hacker" placeholder="Nova Senha" required>
                        <button type="submit" class="btn-start">ATUALIZAR SENHA</button>
                    </form>
                    <div id="message" class="mt-3 text-center"></div>
                    
                    <div class="text-center mt-4">
                        <a href="index.php" style="color: #ff0000; text-decoration: none;">← Voltar ao Dashboard</a>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script>
        let timeLeft = <?php echo $time_left_seconds; ?>;
        function updateTimer() {
            if (timeLeft <= 0) {
                document.getElementById('timer').innerHTML = "EXPIRADO";
                return;
            }
            let d = Math.floor(timeLeft / 86400);
            let h = Math.floor((timeLeft % 86400) / 3600);
            let m = Math.floor((timeLeft % 3600) / 60);
            let s = timeLeft % 60;
            document.getElementById('timer').innerHTML = `${d}d ${h}h ${m}m ${s}s`;
            timeLeft--;
        }
        setInterval(updateTimer, 1000);
        updateTimer();

        document.getElementById('changePasswordForm').addEventListener('submit', function(e) {
            e.preventDefault();
            const current = document.getElementById('current_password').value;
            const newPass = document.getElementById('new_password').value;
            const msg = document.getElementById('message');

            fetch('auth.php?action=change_password', {
                method: 'POST',
                headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                body: `current_password=${encodeURIComponent(current)}&new_password=${encodeURIComponent(newPass)}`
            })
            .then(r => r.json())
            .then(data => {
                msg.innerHTML = data.message;
                msg.style.color = data.status === 'success' ? '#00ff00' : '#ff0000';
                if (data.status === 'success') document.getElementById('changePasswordForm').reset();
            });
        });
    </script>
</body>
</html>
