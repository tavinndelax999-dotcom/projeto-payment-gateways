<?php 
require_once 'config.php';
session_start();

if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}

$username = $_SESSION['username'];
$expires_at = $_SESSION['expires_at'];
$max_devices = $_SESSION['max_devices'] ?? 1;
$allowed_gates = $_SESSION['allowed_gates'] ?? 'all';

// Calcular tempo restante
$now_ts = time();
$expires_ts = strtotime($expires_at);
$time_left_seconds = $expires_ts - $now_ts;

if ($time_left_seconds <= 0) {
    session_destroy();
    header('Location: login.php');
    exit;
}

$days = floor($time_left_seconds / 86400);
$hours = floor(($time_left_seconds % 86400) / 3600);
$minutes = floor(($time_left_seconds % 3600) / 60);
$seconds = $time_left_seconds % 60;
$time_left = sprintf('%d dias, %02d:%02d:%02d', $days, $hours, $minutes, $seconds);

// Filtrar gates permitidos
$available_gates = $AVAILABLE_GATES;
if ($allowed_gates !== 'all') {
    $allowed_list = explode(',', $allowed_gates);
    $available_gates = array_filter($available_gates, function($key) use ($allowed_list) {
        return in_array($key, $allowed_list);
    }, ARRAY_FILTER_USE_KEY);
}
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <title>DRAKENVEIL | DASHBOARD</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600&family=Fira+Code:wght@400;700&display=swap">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/css/toastr.min.css">
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        
        body {
            background: #050000;
            color: #fff;
            font-family: 'Poppins', sans-serif;
            min-height: 100vh;
            overflow-x: hidden;
            position: relative;
        }

        #matrix-canvas {
            position: fixed;
            top: 0;
            left: 0;
            z-index: 0;
            opacity: 0.1;
        }

        .container {
            position: relative;
            z-index: 1;
            padding: 30px 15px;
        }

        .glass-card {
            background: rgba(15, 0, 0, 0.8);
            backdrop-filter: blur(15px);
            border: 1px solid rgba(255, 0, 0, 0.2);
            border-radius: 24px;
            padding: 25px;
            box-shadow: 0 15px 35px rgba(0, 0, 0, 0.5);
            margin-bottom: 25px;
            transition: all 0.3s ease;
        }

        .glass-card:hover {
            border-color: rgba(255, 0, 0, 0.4);
            box-shadow: 0 20px 45px rgba(255, 0, 0, 0.1);
        }

        .header-section {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 30px;
        }

        .brand h1 {
            font-size: 1.5em;
            letter-spacing: 3px;
            font-weight: 700;
            text-shadow: 0 0 15px rgba(255, 0, 0, 0.5);
            margin: 0;
            color: #ff0000;
        }

        .user-badge {
            background: rgba(255, 0, 0, 0.1);
            border: 1px solid rgba(255, 0, 0, 0.3);
            padding: 8px 15px;
            border-radius: 12px;
            font-size: 0.85em;
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .user-badge span { color: #ff0000; font-weight: 600; }

        .stat-grid {
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            gap: 15px;
            margin-bottom: 25px;
        }

        .stat-box {
            background: rgba(255, 255, 255, 0.03);
            border-radius: 18px;
            padding: 20px;
            text-align: center;
            border: 1px solid rgba(255, 255, 255, 0.05);
        }

        .stat-box i { font-size: 1.5em; margin-bottom: 10px; }
        .stat-box.live i { color: #00ff41; }
        .stat-box.die i { color: #ff0000; }
        .stat-box.tested i { color: #00e5ff; }

        .stat-box strong { font-size: 1.8em; display: block; font-family: 'Fira Code', monospace; }
        .stat-box span { font-size: 0.7em; text-transform: uppercase; color: rgba(255, 255, 255, 0.5); letter-spacing: 1px; }

        textarea {
            background: rgba(0, 0, 0, 0.5);
            border: 1px solid rgba(255, 0, 0, 0.2);
            border-radius: 18px;
            color: #ff0000;
            padding: 20px;
            width: 100%;
            font-family: 'Fira Code', monospace;
            font-size: 0.9em;
            resize: none;
            outline: none;
            transition: all 0.3s;
        }

        textarea:focus {
            border-color: #ff0000;
            box-shadow: 0 0 20px rgba(255, 0, 0, 0.2);
        }

        .form-control-hacker {
            background: rgba(255, 255, 255, 0.05);
            border: 1px solid rgba(255, 255, 255, 0.1);
            border-radius: 12px;
            color: #fff;
            padding: 12px 15px;
            width: 100%;
            outline: none;
            margin-bottom: 15px;
        }

        select.form-control-hacker {
            appearance: none;
            background: rgba(255, 0, 0, 0.05);
            border-color: rgba(255, 0, 0, 0.2);
            color: #ff0000;
            font-weight: 600;
        }

        .btn-action {
            padding: 15px;
            border-radius: 15px;
            font-weight: 600;
            letter-spacing: 1px;
            transition: all 0.3s;
            border: none;
            width: 100%;
            margin-bottom: 10px;
            text-transform: uppercase;
        }

        .btn-start { background: linear-gradient(135deg, #ff0000 0%, #8b0000 100%); color: #fff; box-shadow: 0 10px 20px rgba(255, 0, 0, 0.2); }
        .btn-start:hover { transform: translateY(-3px); box-shadow: 0 15px 30px rgba(255, 0, 0, 0.4); }

        .btn-stop { background: rgba(255, 255, 255, 0.05); color: #fff; border: 1px solid rgba(255, 255, 255, 0.1); }
        .btn-stop:hover { background: rgba(255, 255, 255, 0.1); }

        .log-container {
            max-height: 350px;
            overflow-y: auto;
            border-radius: 18px;
            background: rgba(0, 0, 0, 0.3);
            padding: 15px;
            font-family: 'Fira Code', monospace;
            font-size: 0.8em;
        }

        .log-item {
            padding: 10px;
            border-bottom: 1px solid rgba(255, 255, 255, 0.03);
            animation: slideIn 0.3s ease-out;
        }

        @keyframes slideIn { from { opacity: 0; transform: translateX(-10px); } to { opacity: 1; transform: translateX(0); } }

        .log-live { color: #00ff41; background: rgba(0, 255, 65, 0.05); border-left: 3px solid #00ff41; }
        .log-die { color: #ff0000; background: rgba(255, 0, 0, 0.05); border-left: 3px solid #ff0000; }

        .nav-pills-hacker {
            display: flex;
            gap: 10px;
            margin-bottom: 20px;
        }

        .nav-pills-hacker .nav-link {
            background: rgba(255, 255, 255, 0.05);
            color: rgba(255, 255, 255, 0.5);
            border-radius: 12px;
            padding: 10px 20px;
            font-size: 0.85em;
            font-weight: 600;
            border: none;
        }

        .nav-pills-hacker .nav-link.active {
            background: #ff0000;
            color: #fff;
            box-shadow: 0 5px 15px rgba(255, 0, 0, 0.3);
        }

        .info-footer {
            text-align: center;
            font-size: 0.7em;
            color: rgba(255, 255, 255, 0.3);
            letter-spacing: 2px;
            margin-top: 20px;
        }

        @media (max-width: 768px) {
            .stat-grid { grid-template-columns: 1fr; }
            .header-section { flex-direction: column; gap: 15px; }
            .brand h1 { font-size: 1.2em; }
        }
    </style>
</head>
<body>

<canvas id="matrix-canvas"></canvas>

<div class="container">
    <div class="header-section">
        <div class="brand">
            <h1>DRAKENVEIL_CORE <span id="global-status" class="badge badge-secondary" style="font-size: 0.4em; vertical-align: middle; letter-spacing: 1px;">IDLE</span></h1>
        </div>
        <div class="d-flex align-items-center gap-3">
            <div class="user-badge" onclick="window.location.href='profile.php'" style="cursor: pointer;">
                <i class="fas fa-user"></i> <span><?php echo $username; ?></span>
            </div>
            <a href="auth.php?action=logout" class="btn btn-sm btn-outline-danger border-0"><i class="fas fa-power-off"></i></a>
        </div>
    </div>

    <div class="row">
        <div class="col-lg-8">
            <div class="glass-card">
                <div class="stat-grid">
                    <div class="stat-box live">
                        <i class="fas fa-check-circle"></i>
                        <strong class="val-lives">0</strong>
                        <span>Aprovados</span>
                    </div>
                    <div class="stat-box die">
                        <i class="fas fa-times-circle"></i>
                        <strong class="val-dies">0</strong>
                        <span>Reprovados</span>
                    </div>
                    <div class="stat-box tested">
                        <i class="fas fa-microchip"></i>
                        <strong class="val-tested">0/0</strong>
                        <span>Testados</span>
                    </div>
                </div>

                <textarea id="lista_cartoes" rows="8" placeholder="Cole sua lista aqui..."></textarea>
            </div>
        </div>

        <div class="col-lg-4">
            <div class="glass-card">
                <label class="small text-muted mb-2 text-uppercase font-weight-bold">Configuração de Gate</label>
                <select id="gateway" class="form-control-hacker">
                    <?php foreach ($available_gates as $gate => $label): ?>
                        <option value="<?php echo $gate; ?>"><?php echo $label; ?></option>
                    <?php endforeach; ?>
                </select>

                <div class="mt-4">
                    <button class="btn-action btn-start" id="chk-start">Iniciar Sequência</button>
                    <button class="btn-action btn-stop" id="chk-stop" disabled>Abortar</button>
                    <button class="btn-action btn-stop" id="chk-clean" style="opacity: 0.5;">Limpar Logs</button>
                </div>

                <div class="mt-3 small text-muted text-center">
                    Dispositivos: <?php echo $max_devices === 999 ? 'Ilimitado' : $max_devices; ?>
                </div>
            </div>
        </div>
    </div>

    <div class="glass-card">
        <div class="d-flex justify-content-between align-items-center mb-3">
            <ul class="nav nav-pills nav-pills-hacker" id="pills-tab" role="tablist" style="margin-bottom: 0;">
                <li class="nav-item"><a class="nav-link active" data-toggle="pill" href="#pills-lives">Lives</a></li>
                <li class="nav-item"><a class="nav-link" data-toggle="pill" href="#pills-dies">Dies</a></li>
                <li class="nav-item"><a class="nav-link" data-toggle="pill" href="#pills-errors">Erros</a></li>
            </ul>
            <button class="btn btn-sm btn-success" onclick="copyLives()" style="border-radius: 10px; font-weight: 600;"><i class="fas fa-copy mr-1"></i> COPIAR LIVES</button>
        </div>
        <div class="tab-content">
            <div class="tab-pane fade show active" id="pills-lives">
                <div id="lives" class="log-container"></div>
            </div>
            <div class="tab-pane fade" id="pills-dies">
                <div id="dies" class="log-container"></div>
            </div>
            <div class="tab-pane fade" id="pills-errors">
                <div id="errors" class="log-container"></div>
            </div>
        </div>
    </div>

    <div class="info-footer">
        TIME_LEFT: <span id="realtime-clock"><?php echo $time_left; ?></span> // ENCRYPTED_BY_DRAKENVEIL
    </div>
</div>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/js/toastr.min.js"></script>

<script>
function copyLives() {
    let lives = [];
    $('#lives .log-item').each(function() {
        let text = $(this).text().replace('LIVE | ', '');
        lives.push(text);
    });
    if (lives.length === 0) {
        toastr.warning('NENHUMA LIVE PARA COPIAR');
        return;
    }
    let fullText = lives.join('\n');
    let tempInput = $('<textarea>');
    $('body').append(tempInput);
    tempInput.val(fullText).select();
    document.execCommand('copy');
    tempInput.remove();
    toastr.success('LIVES COPIADAS!');
}

// Matrix Effect Red
const canvas = document.getElementById('matrix-canvas');
const ctx = canvas.getContext('2d');
canvas.width = window.innerWidth;
canvas.height = window.innerHeight;
const letters = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
const fontSize = 14;
const columns = canvas.width / fontSize;
const drops = [];
for (let i = 0; i < columns; i++) drops[i] = 1;

function drawMatrix() {
    ctx.fillStyle = 'rgba(0, 0, 0, 0.05)';
    ctx.fillRect(0, 0, canvas.width, canvas.height);
    ctx.fillStyle = '#ff0000';
    ctx.font = fontSize + 'px monospace';
    for (let i = 0; i < drops.length; i++) {
        const text = letters.charAt(Math.floor(Math.random() * letters.length));
        ctx.fillText(text, i * fontSize, drops[i] * fontSize);
        if (drops[i] * fontSize > canvas.height && Math.random() > 0.975) drops[i] = 0;
        drops[i]++;
    }
}
setInterval(drawMatrix, 50);

// Real-time Countdown
let timeLeftSeconds = <?php echo $time_left_seconds; ?>;
function updateClock() {
    if (timeLeftSeconds <= 0) {
        document.getElementById('realtime-clock').innerHTML = "EXPIRADO";
        window.location.href = 'login.php';
        return;
    }
    
    let d = Math.floor(timeLeftSeconds / 86400);
    let h = Math.floor((timeLeftSeconds % 86400) / 3600);
    let m = Math.floor((timeLeftSeconds % 3600) / 60);
    let s = timeLeftSeconds % 60;
    
    let clockStr = d + " dias, " + 
                   (h < 10 ? "0" + h : h) + ":" + 
                   (m < 10 ? "0" + m : m) + ":" + 
                   (s < 10 ? "0" + s : s);
    
    document.getElementById('realtime-clock').innerHTML = clockStr;
    timeLeftSeconds--;
}
setInterval(updateClock, 1000);

// Checker Logic
$(document).ready(function() {
    let tested = 0, lives = 0, dies = 0;
    let stopped = true;

    let totalCards = 0;
    function processar() {
        if (stopped) return;
        let textarea = $('#lista_cartoes');
        let text = textarea.val();
        let lines = text.split('\n').filter(l => l.trim());
        
        if (lines.length === 0) {
            stopped = true;
            $('#chk-start').html('Iniciar Sequência').prop('disabled', false);
            $('#chk-stop').prop('disabled', true);
            $('#global-status').text('IDLE').removeClass('badge-success badge-danger').addClass('badge-secondary');
            toastr.success('SEQUÊNCIA FINALIZADA');
            return;
        }

        let currentCard = lines[0].trim();
        let linha = currentCard;
        
        if (!linha) { 
            stopped = true;
            $('#chk-start').html('Iniciar Sequência').prop('disabled', false);
            $('#chk-stop').prop('disabled', true);
            $('#global-status').text('IDLE').removeClass('badge-success badge-danger').addClass('badge-secondary');
            toastr.success('SEQUÊNCIA FINALIZADA');
            return; 
        }

        let gateway = $('#gateway').val();

        $.ajax({
            url: './' + gateway,
            type: 'POST',
            data: { lista: linha },
            timeout: 60000,
            success: function(res) {
                tested++;
                if (!res || res.trim() === "") {
                    $('#errors').prepend('<div class="log-item text-warning"><b>ERRO</b> | Retorno vazio da gate</div>');
                } else if (res.startsWith('LIVE')) {
                    lives++;
                    $('#lives').prepend('<div class="log-item log-live">' + res + '</div>');
                    toastr.success("LIVE DETECTADA");
                } else if (res.startsWith('DIE') || res.toLowerCase().includes('card_generic_error')) {
                    dies++;
                    $('#dies').prepend('<div class="log-item log-die">' + res + '</div>');
                } else if (res.startsWith('ERRO') || res.startsWith('AVISO')) {
                    $('#errors').prepend('<div class="log-item text-warning">' + res + '</div>');
                } else {
                    dies++;
                    $('#dies').prepend('<div class="log-item log-die">DIE | ' + res + '</div>');
                }
                $('.val-lives').text(lives); $('.val-dies').text(dies); $('.val-tested').text(tested + '/' + totalCards);
                lines.shift();
                textarea.val(lines.join('\n'));
                setTimeout(processar, 100);
            },
            error: function(xhr, status, error) {
                $('#errors').prepend('<div class="log-item text-danger"><b>ERRO HTTP</b> | ' + status + ': ' + error + '</div>');
                lines.shift();
                textarea.val(lines.join('\n'));
                setTimeout(processar, 100);
            }
        });
    }

    $('#chk-start').click(function() {
        let textarea = $('#lista_cartoes');
        let cardPattern = /\d{15,16}[\s|:;,-]\d{1,2}[\s|:;,-]\d{2,4}[\s|:;,-]\d{3,4}/g;
        let matches = textarea.val().match(cardPattern);
        
        if (!matches || matches.length === 0) {
            toastr.error('SISTEMA: NENHUM CARTÃO ENCONTRADO');
            return;
        }

        // Limpa o textarea deixando apenas os cartões formatados
        let cleanList = matches.map(c => c.replace(/[\s|:;,-]+/g, '|')).join('\n');
        textarea.val(cleanList);

        totalCards = matches.length;
        tested = 0; lives = 0; dies = 0;
        $('.val-lives, .val-dies').text('0');
        $('.val-tested').text('0/' + totalCards);
        stopped = false;
        $(this).html('<i class="fas fa-spinner fa-spin mr-2"></i>PROCESSANDO...').prop('disabled', true);
        $('#chk-stop').prop('disabled', false);
        $('#global-status').text('RUNNING').removeClass('badge-secondary badge-danger').addClass('badge-success');
        toastr.info('SISTEMA: SEQUÊNCIA INICIADA');
        processar();
    });

    $('#chk-stop').click(function() {
        stopped = true;
        $(this).prop('disabled', true);
        $('#chk-start').html('Iniciar Sequência').prop('disabled', false);
        $('#global-status').text('ABORTED').removeClass('badge-success').addClass('badge-danger');
        toastr.warning('SISTEMA: SEQUÊNCIA ABORTADA');
    });

    $('#chk-clean').click(function() {
        $('#lives, #dies, #errors').html('');
        tested = 0; lives = 0; dies = 0;
        $('.val-lives, .val-dies').text('0');
        $('.val-tested').text('0/0');
    });
});
</script>
</body>
</html>
