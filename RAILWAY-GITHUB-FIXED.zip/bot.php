<?php
require_once 'config.php';

$update = json_decode(file_get_contents('php://input'), true);

// Log de depuração (opcional, remova depois)
// file_put_contents('debug.log', json_encode($update) . PHP_EOL, FILE_APPEND);

// Processar callback queries (botões)
if (isset($update['callback_query'])) {
    $from_id = $update['callback_query']['from']['id'];
    
    // Validar se é o ADMIN que está clicando
    if ($from_id != ADMIN_ID) {
        sendTelegram('answerCallbackQuery', [
            'callback_query_id' => $update['callback_query']['id'],
            'text' => '❌ Você não tem permissão para aprovar.',
            'show_alert' => true
        ]);
        exit;
    }
    $callback_id = $update['callback_query']['id'];
    $data = $update['callback_query']['data'];
    $chat_id = $update['callback_query']['message']['chat']['id'];
    $message_id = $update['callback_query']['message']['message_id'];

    // Fluxo de Aprovação - Passo 1: Escolher Tempo
    if (strpos($data, 'approve_') === 0) {
        $username = str_replace('approve_', '', $data);
        
        $keyboard = [
            'inline_keyboard' => [
                [['text' => '⏰ 30 minutos', 'callback_data' => "time_30m_$username"]],
                [['text' => '⏰ 1 hora', 'callback_data' => "time_1h_$username"]],
                [['text' => '⏰ 6 horas', 'callback_data' => "time_6h_$username"]],
                [['text' => '⏰ 24 horas', 'callback_data' => "time_24h_$username"]],
                [['text' => '⏰ 7 dias', 'callback_data' => "time_7d_$username"]],
                [['text' => '⏰ 30 dias', 'callback_data' => "time_30d_$username"]],
                [['text' => '❌ Recusar', 'callback_data' => "reject_$username"]]
            ]
        ];

        sendTelegram('editMessageText', [
            'chat_id' => $chat_id,
            'message_id' => $message_id,
            'text' => "👤 *Usuário: `$username`*\n\n⏱️ *Selecione o tempo de acesso:*",
            'parse_mode' => 'Markdown',
            'reply_markup' => json_encode($keyboard)
        ]);

        sendTelegram('answerCallbackQuery', ['callback_query_id' => $callback_id]);
    }

    // Passo 2: Escolher Tempo - Calcular Expiração
    if (preg_match('/^time_(.*?)_(.*)$/', $data, $matches)) {
        sendTelegram('answerCallbackQuery', ['callback_query_id' => $callback_id]);
        $time_val = $matches[1];
        $username = $matches[2];

        $time_map = [
            '30m' => '+30 minutes',
            '1h' => '+1 hour',
            '6h' => '+6 hours',
            '24h' => '+24 hours',
            '7d' => '+7 days',
            '30d' => '+30 days'
        ];

        $expires = date('Y-m-d H:i:s', strtotime($time_map[$time_val]));

        // Passo 3: Escolher Número de Dispositivos
        $keyboard = [
            'inline_keyboard' => [
                [['text' => '📱 1 dispositivo', 'callback_data' => "devices_1_${time_val}_$username"]],
                [['text' => '📱 2 dispositivos', 'callback_data' => "devices_2_${time_val}_$username"]],
                [['text' => '📱 3 dispositivos', 'callback_data' => "devices_3_${time_val}_$username"]],
                [['text' => '📱 5 dispositivos', 'callback_data' => "devices_5_${time_val}_$username"]],
                [['text' => '📱 Ilimitado', 'callback_data' => "devices_unlimited_${time_val}_$username"]]
            ]
        ];

        sendTelegram('editMessageText', [
            'chat_id' => $chat_id,
            'message_id' => $message_id,
            'text' => "👤 *Usuário: `$username`*\n⏱️ *Tempo: `$time_val`*\n\n📱 *Selecione o número de dispositivos:*",
            'parse_mode' => 'Markdown',
            'reply_markup' => json_encode($keyboard)
        ]);

        sendTelegram('answerCallbackQuery', ['callback_query_id' => $callback_id]);
    }

    // Passo 3: Escolher Gates (Múltipla Escolha com IDs Curtos)
    if (preg_match('/^devices_(.*)_(.*)_(.*)$/', $data, $matches)) {
        $devices = $matches[1]; $time_val = $matches[2]; $username = $matches[3];
        $gates_list = ['p3'=>'💎 P3', 'p1'=>'🔵 P1', 'p2'=>'🟢 P2', 'er'=>'🟠 ER', 's0'=>'🟣 S0', 'se'=>'🟡 SE', 'br'=>'🔴 BR'];
        $kb = [];
        foreach ($gates_list as $k => $v) { $kb[] = [['text' => $v, 'callback_data' => "ga_{$k}_{$devices}_{$time_val}_{$username}|"]]; }
        $kb[] = [['text' => '✅ Todos os Gates', 'callback_data' => "gate_final_all_{$devices}_{$time_val}_{$username}"]];
        sendTelegram('editMessageText', ['chat_id' => $chat_id, 'message_id' => $message_id, 'text' => "👤 *Usuário: `$username`*\n🔌 *Selecione os Gates:*", 'parse_mode' => 'Markdown', 'reply_markup' => json_encode(['inline_keyboard' => $kb])]);
        sendTelegram('answerCallbackQuery', ['callback_query_id' => $callback_id]);
    }

    // Passo 4: Toggle Gate (Adicionar/Remover)
    if (preg_match('/^ga_(.*)_(.*)_(.*)_(.*)\|(.*)$/', $data, $matches)) {
        $short = $matches[1]; $devs = $matches[2]; $time = $matches[3]; $user = $matches[4]; $current = $matches[5];
        $map = ['p3'=>'paypal3.php', 'p1'=>'paypal1.php', 'p2'=>'paypal.php', 'er'=>'erede1.php', 's0'=>'stripe0auth.php', 'se'=>'stripeee.php', 'br'=>'braindokgarr.php'];
        $gates_arr = $current ? explode(',', $current) : [];
        if (in_array($short, $gates_arr)) { $gates_arr = array_diff($gates_arr, [$short]); } else { $gates_arr[] = $short; }
        $new_str = implode(',', $gates_arr);
        $gates_list = ['p3'=>'💎 P3', 'p1'=>'🔵 P1', 'p2'=>'🟢 P2', 'er'=>'🟠 ER', 's0'=>'🟣 S0', 'se'=>'🟡 SE', 'br'=>'🔴 BR'];
        $kb = [];
        foreach ($gates_list as $k => $v) { 
            $p = in_array($k, $gates_arr) ? "✅ " : "";
            $kb[] = [['text' => $p.$v, 'callback_data' => "ga_{$k}_{$devs}_{$time}_{$user}|{$new_str}"]]; 
        }
        // Converter de volta para nomes de arquivos ao finalizar
        $final_files = []; foreach($gates_arr as $g) { $final_files[] = $map[$g]; }
        $final_str = implode(',', $final_files);
        $kb[] = [['text' => '🚀 FINALIZAR ('.count($gates_arr).')', 'callback_data' => "gate_final_{$final_str}_{$devs}_{$time}_{$user}"]];
        $kb[] = [['text' => '🌐 TODOS', 'callback_data' => "gate_final_all_{$devs}_{$time}_{$user}"]];
        sendTelegram('editMessageText', ['chat_id' => $chat_id, 'message_id' => $message_id, 'text' => "👤 *Usuário: `$user`*\n🔌 *Gates Selecionadas: " . count($gates_arr) . "*", 'parse_mode' => 'Markdown', 'reply_markup' => json_encode(['inline_keyboard' => $kb])]);
        sendTelegram('answerCallbackQuery', ['callback_query_id' => $callback_id]);
    }

    // Passo Final: Salvar Usuário com Todas as Restrições
    if (preg_match('/^gate_final_(.*)_(.*)_(.*)_(.*)$/', $data, $matches)) {
        sendTelegram('answerCallbackQuery', ['callback_query_id' => $callback_id]);
        $gates = $matches[1];
        $devices = $matches[2];
        $time_val = $matches[3];
        $username = $matches[4];

        if (!$gates) {
            sendTelegram('answerCallbackQuery', ['callback_query_id' => $callback_id, 'text' => '❌ Selecione ao menos uma gate!', 'show_alert' => true]);
            exit;
        }

        $time_map = [
            '30m' => '+30 minutes',
            '1h' => '+1 hour',
            '6h' => '+6 hours',
            '24h' => '+24 hours',
            '7d' => '+7 days',
            '30d' => '+30 days'
        ];

        $expires = date('Y-m-d H:i:s', strtotime($time_map[$time_val]));
        $max_dev = ($devices === 'unlimited') ? 999 : intval($devices);
        $allowed_gates = ($gates === 'all') ? 'all' : $gates;

        try {
            $stmt = $db->prepare("UPDATE users SET status = 'approved', expires_at = ?, max_devices = ?, allowed_gates = ? WHERE username = ?");
            $stmt->execute([$expires, $max_dev, $allowed_gates, $username]);

            $msg = "✅ *Usuário Aprovado*\n\n👤 `$username`\n⏱️ Expira em: `$expires`\n📱 Dispositivos: `$devices`\n🔌 Gates: `" . ($gates === 'all' ? 'TODOS' : $gates) . "`";

            sendTelegram('editMessageText', [
                'chat_id' => $chat_id,
                'message_id' => $message_id,
                'text' => $msg,
                'parse_mode' => 'Markdown'
            ]);
        } catch (Exception $e) {
            sendTelegram('editMessageText', [
                'chat_id' => $chat_id,
                'message_id' => $message_id,
                'text' => "❌ Erro ao aprovar usuário: " . $e->getMessage(),
                'parse_mode' => 'Markdown'
            ]);
        }

        sendTelegram('answerCallbackQuery', ['callback_query_id' => $callback_id]);
    }

    // Rejeitar Usuário
    if (strpos($data, 'reject_') === 0) {
        $username = str_replace('reject_', '', $data);
        $stmt = $db->prepare("UPDATE users SET status = 'blocked' WHERE username = ?");
        $stmt->execute([$username]);

        sendTelegram('editMessageText', [
            'chat_id' => $chat_id,
            'message_id' => $message_id,
            'text' => "❌ *Usuário `$username` RECUSADO/BLOQUEADO.*",
            'parse_mode' => 'Markdown'
        ]);

        sendTelegram('answerCallbackQuery', ['callback_query_id' => $callback_id, 'text' => 'Usuário recusado!']);
    }
}

// Comandos de Painel no Telegram
if (isset($update['message'])) {
    $text = $update['message']['text'] ?? '';
    $chat_id = $update['message']['chat']['id'] ?? $update['message']['from']['id'];

    if ($chat_id == ADMIN_ID) {
        if ($text == '/start') {
            $msg = "🖥️ *Painel Admin Drakenveil*\n\n*Comandos:*\n";
            $msg .= "`/list` - Listar usuários\n";
            $msg .= "`/del [user]` - Remover usuário\n";
            $msg .= "`/extend [user] [horas]` - Estender tempo\n";
            $msg .= "`/restrict [user] [gate]` - Restringir gate\n";

            sendTelegram('sendMessage', [
                'chat_id' => $chat_id,
                'text' => $msg,
                'parse_mode' => 'Markdown'
            ]);
        }

        if ($text == '/list') {
            $stmt = $db->query("SELECT username, status, expires_at, max_devices, allowed_gates FROM users ORDER BY created_at DESC LIMIT 10");
            $users = $stmt->fetchAll(PDO::FETCH_ASSOC);

            $msg = "📋 *Últimos 10 Usuários:*\n\n";
            foreach ($users as $u) {
                $msg .= "👤 `{$u['username']}`\n";
                $msg .= "   Status: `{$u['status']}`\n";
                $msg .= "   Expira: `{$u['expires_at']}`\n";
                $msg .= "   Dispositivos: `{$u['max_devices']}`\n";
                $msg .= "   Gates: `{$u['allowed_gates']}`\n\n";
            }

            sendTelegram('sendMessage', [
                'chat_id' => $chat_id,
                'text' => $msg,
                'parse_mode' => 'Markdown'
            ]);
        }

        if (preg_match('/^\/del (\w+)$/', $text, $matches)) {
            $user = $matches[1];
            $stmt = $db->prepare("DELETE FROM users WHERE username = ?");
            $stmt->execute([$user]);
            sendTelegram('sendMessage', [
                'chat_id' => $chat_id,
                'text' => "🗑️ Usuário `$user` removido.",
                'parse_mode' => 'Markdown'
            ]);
        }

        if (preg_match('/^\/extend (\w+) (\d+)$/', $text, $matches)) {
            $user = $matches[1];
            $hours = $matches[2];
            $expires = date('Y-m-d H:i:s', strtotime("+$hours hours"));
            $stmt = $db->prepare("UPDATE users SET expires_at = ? WHERE username = ?");
            $stmt->execute([$expires, $user]);
            sendTelegram('sendMessage', [
                'chat_id' => $chat_id,
                'text' => "⏱️ Adicionado $hours horas para `$user`. Novo expira: `$expires`",
                'parse_mode' => 'Markdown'
            ]);
        }

        if (preg_match('/^\/restrict (\w+) (.+)$/', $text, $matches)) {
            $user = $matches[1];
            $gate = $matches[2]; // ex: paypal.php ou all
            $stmt = $db->prepare("UPDATE users SET allowed_gates = ? WHERE username = ?");
            $stmt->execute([$gate, $user]);
            sendTelegram('sendMessage', [
                'chat_id' => $chat_id,
                'text' => "🔒 Gate de `$user` atualizada para: `$gate`",
                'parse_mode' => 'Markdown'
            ]);
        }
    }
}
?>
